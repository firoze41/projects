<?php include('header.php');?>

<?php include('admin-menu.php');?>

<!-- pgwslider edit start -->
<?php 
if(isset($_REQUEST['id'])){
	$id = $_REQUEST['id'];
}
?>

<?php
if(isset($_REQUEST['form1'])){

header('location:post-update.php');

	try{
		if(empty( $_REQUEST['post_title'] )){
			throw new PDOException('Post title can\'n be empty');
		}
		if(empty( $_REQUEST['post_location'] )){
			throw new PDOException('Location can\'n be empty');
		}
	// File uploads start	File uploaded php code has teken from w3school 
		
	if(empty($_FILES["post_image"]["name"])){
		$stmt = $con->prepare("UPDATE tbl_pgslider SET post_title=?,post_location=? WHERE post_id=?");
		$stmt->execute(array($_REQUEST['post_title'],$_REQUEST['post_location'],$id));
	}
	else{
		// Image uploading
		$target_file = $_FILES["post_image"]["name"];
		$file_basename = substr($target_file, 0, strripos($target_file, '.')); // strip extention
		$file_ext = substr($target_file, strripos($target_file, '.')); // strip name
		$f1 = $id. $file_ext;
		
		
		$uploadOk = 1;
		$imageFileType = pathinfo($f1,PATHINFO_EXTENSION);
		
		
		// Check if image file is a actual image or fake image

			$check = getimagesize($_FILES["post_image"]["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				echo "File is not an image.";
				$uploadOk = 0;
			}

		
		// Check if file already exists
		if (file_exists($f1)) {
			echo "Sorry, file already exists.";
			$uploadOk = 0;
		}
		// Check file size
		if ($_FILES["post_image"]["size"] > 500000) {
			echo "Sorry, your file is too large.";
			$uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
		
		// First image will be selected from tbl_pgslider then image will be deleted from folder	
		$stmt = $con->prepare("SELECT * FROM tbl_pgslider WHERE post_id='$id'");
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		foreach($result as $row){
			$real_path = "/uploads/".$row['post_image'];
			unlink($real_path);
		}
		
		
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
		// if everything is ok, try to upload file
		} else {
			if (move_uploaded_file($_FILES["post_image"]["tmp_name"],'uploads/'. $f1)) {
				//echo "The file ". basename( $_FILES["post_image"]["name"]). " has been uploaded.";
			} else {
				echo "Sorry, there was an error uploading your file.";
			}
		}
	// File uploas end	
		

			// data select to check exists data
			$sql = "SELECT * FROM tbl_pgslider WHERE post_title=?";
			$stmt = $con -> prepare($sql);
			$stmt->execute(array($_REQUEST['post_title']));
			
			// Exists data checking
			$count = $stmt->rowCount();
			if( $count > 0 ){
				throw new PDOException("Data already existis");
			}
		 
		 
		 
		 
		 
			if($uploadOk == true){
				$stmt = $con->prepare("UPDATE tbl_pgslider SET post_title=?,post_location=?,post_image=? WHERE post_id=?");
				$stmt->execute(array($_REQUEST['post_title'],$_REQUEST['post_location'],$_REQUEST['post_image'],$id));
			}
	}
		
		

	$success_message = "Data has been UPDATED in database successfully";
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}
}
?>
<!-- pgwslider edit end -->

<table style="text-align:center">
	
<?php
// pgw_slider_slideshow
$stmt = $con->prepare("SELECT *  FROM tbl_pgslider WHERE post_id=?");
$stmt->execute(array($id));
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$i=0;
foreach($result as $row){

}
?>
	<tr>
			<p>
			<form action="" method="post" enctype="multipart/form-data">
				<table>
					<tr>
						<td>Post Title</td>
						<td><input type="text" value="<?php echo $row['post_title'];?>" name="post_title" /></td>
					</tr>
					<tr>
						<td>Location</td>
						<td><input type="text" value="<?php echo $row['post_location'];?>" name="post_location" /></td>
					</tr>
					<tr>
						<img width="350" height="" src="uploads/<?php echo $row['post_image'];?>" alt="" />
					</tr>
					<tr>
						<td>Upload Image</td>
						<td><input type="file" name="post_image" id="post_image" /></td>
					</tr>
					<tr>
						<td></td>
						<td><input type="submit" value="Update" name="form1" /></td>
					</tr>
				</table>
			</form>
			</p>		
	</tr>
<?php

?>

</table>



	
<?php //include('pgwslider.php');?>	
	

<?php include('footer.php');?>