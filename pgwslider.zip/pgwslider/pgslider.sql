-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2016 at 06:29 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pgslider`
--

-- --------------------------------------------------------

--
-- Table structure for table `pgw_customize`
--

CREATE TABLE `pgw_customize` (
  `position_id1` int(2) NOT NULL,
  `slide_position1` varchar(50) NOT NULL,
  `position_id2` int(2) NOT NULL,
  `slide_position2` varchar(50) NOT NULL,
  `position_id3` int(2) NOT NULL,
  `slide_position3` varchar(50) NOT NULL,
  `position_id4` int(2) NOT NULL,
  `slide_position4` varchar(50) NOT NULL,
  `position_id5` int(2) NOT NULL,
  `slide_position5` varchar(50) NOT NULL,
  `position_id6` int(2) NOT NULL,
  `slide_position6` varchar(50) NOT NULL,
  `position_id7` int(2) NOT NULL,
  `slide_position7` varchar(50) NOT NULL,
  `color_id8` int(1) NOT NULL,
  `color_position8` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pgw_customize`
--

INSERT INTO `pgw_customize` (`position_id1`, `slide_position1`, `position_id2`, `slide_position2`, `position_id3`, `slide_position3`, `position_id4`, `slide_position4`, `position_id5`, `slide_position5`, `position_id6`, `slide_position6`, `position_id7`, `slide_position7`, `color_id8`, `color_position8`) VALUES
(1, 'left', 2, 'true', 3, 'true', 4, 'fading', 5, 'mouseOver', 6, 'pgwSlider', 7, '2', 8, '#86a877');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pgslider`
--

CREATE TABLE `tbl_pgslider` (
  `post_id` int(3) NOT NULL,
  `post_title` text NOT NULL,
  `post_location` varchar(200) NOT NULL,
  `post_image` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pgw_customize`
--
ALTER TABLE `pgw_customize`
  ADD PRIMARY KEY (`position_id1`);

--
-- Indexes for table `tbl_pgslider`
--
ALTER TABLE `tbl_pgslider`
  ADD PRIMARY KEY (`post_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pgw_customize`
--
ALTER TABLE `pgw_customize`
  MODIFY `position_id1` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_pgslider`
--
ALTER TABLE `tbl_pgslider`
  MODIFY `post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
