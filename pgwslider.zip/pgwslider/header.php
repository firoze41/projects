


<?php include('config.php');?>
<?php
// pgw_slider_slideshow
$stmt = $con->prepare("SELECT * FROM pgw_customize WHERE position_id6=6");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['slide_position6'];
}
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Pgwslider and Pgwslideshow</title>
	<!-- customize css php -->
	<link rel="stylesheet" type="text/css" href="css/customize.css"/>
	<!-- Color Picker Start -->
	<link rel="stylesheet" type="text/css" href="css/spectrum.css"/>
	<!-- Color Picker End -->
	
	<link rel="stylesheet" type="text/css" href="css/<?php echo (strtolower($row['slide_position6']));?>.css"/>
	
	<?php
	if($row['slide_position6'] == 'pgwSlideshow'){
		?>
		<link rel="stylesheet" type="text/css" href="css/<?php echo (strtolower($row['slide_position6']));?>_light.css"/>
		<?php
	}
	?>
	
	
	<link rel="stylesheet" type="text/css" href="style.css"/>

</head>
<body>
