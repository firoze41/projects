<?php
// pgw_slider_slideshow SELECT To Preview 
$stmt = $con->prepare('SELECT *  FROM pgw_customize WHERE position_id6=6');
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['slide_position6']; // pgw_slider_slideshow
}
?>	

	<script src='js/jquery_latest.js'></script>	
	<!-- Color Picker Start -->
	<script src='js/spectrum.js'></script>	
	<script type='text/javascript' src="js/customize.js"></script>
	<!-- pgwSlider or pgwSlideshow -->
	<?php $slider_lower = strtolower($row['slide_position6']);?>
	<script src='<?php echo "js/$slider_lower.js";?>'></script>
	
	<!-- confirm delete  script -->
	<script>
	function confirmDelete(){
			return confirm('Do you want to delete this data ?');
	}
	</script>
	

	
	
</body>
</html>
