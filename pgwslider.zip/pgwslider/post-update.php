<?php include('header.php');?>

<?php include('admin-menu.php');?>



<?php 
if(isset($_REQUEST['id'])){
	$id = $_REQUEST['id'];
	
 // First image will be selected from tbl_pgslider then image will be deleted from folder	
$stmt = $con->prepare("SELECT * FROM tbl_pgslider WHERE post_id='$id'");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$real_path = "uploads/".$row['post_image'];
	unlink($real_path);
}


// Post delete from tbl_pgslider from the server
$stmt = $con->prepare("DELETE FROM tbl_pgslider WHERE post_id='$id'");
$stmt->execute();
$success_message = "Post Has been deleted successfully";

}
?>


<table style="text-align:center">
<tr><h1>Update / Delete</h1></tr>
	<tr>
		<th class="first_th">Serial No..</th>
		<th class="first_th">Post Title</th>
		<th class="first_th">Post Location</th>
		<th class="first_th">Image</th>
		<th class="first_th">Actions</th>
		
	</tr>
	
<?php
// pgw_slider_slideshow
$stmt = $con->prepare("SELECT *  FROM tbl_pgslider");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$count = $stmt->rowCount();
$i=0;
if($count > 0){
foreach($result as $row){
	$post_id = $row['post_id'];
$i++;

?>

<tr>
	<th><?php echo $i;?></th>
	<th><?php echo $row['post_title'];?></th>
	<th><?php echo $row['post_location'];?></th>
	<th><img width="50" height="40" src="uploads/<?php echo $row['post_image'];?>" alt="" /></th>
	<th>
	<a style="color:#111" href="post-edit.php?id=<?php echo $row['post_id'];?>" title="">Edit</a>			
	/ 
<a  style="color:#111" onclick="return confirmDelete();" href="post-update.php?id=<?php echo $row['post_id'];?>">Delete</a></th>
</tr>


<?php
}

}
else{
for($j=1;$j<=5;$j++){
		?>	
	<tr>
	<th><?php echo $j;?></th>
	<th>Default Title</th>
	<th>your location</th>
	<th><img width="50" height="40" src="images/image<?php echo $j;?>.jpg" alt="" /></th>
	<th>Nothing</th>

	</tr>
	<?php
}	

}


?>

</table>

<style type="text/css">
th.first_th{background:#8DD241;padding:10px}
table tr:nth-child(2n){background:#1E96C2}
table tr:nth-child(2n+1){background:#CBE4F8}
</style>	
<?php //include('pgwslider.php');?>	
	

<?php include('footer.php');?>