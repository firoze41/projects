<?php include('header.php');?>
<?php include('admin-menu.php');?>

<?php
// Only for counting total row
$stmt = $con->prepare("SELECT * FROM tbl_pgslider");
$stmt->execute();
$count = $stmt->rowCount();
?>

<?php
// 
if(isset($_REQUEST['form1'])){
	try{
		
        // Customize AND Update
		$stmt = $con->prepare("UPDATE pgw_customize SET 
													slide_position1=?,
													slide_position2=?,
													slide_position3=?, 
													slide_position4=?,
													slide_position5=?,
													slide_position6=?,
													slide_position7=?,
													
													color_position8=? 
													WHERE 
													position_id1=1 AND 
													position_id2=2 AND 
													position_id3=3 AND 
													position_id4=4 AND 
													position_id5=5 AND 
													position_id6=6 AND 
													position_id7=7 AND
													
													color_id8=8
							
							");
		$stmt->execute(array(
							$_REQUEST['slide_position1'],
							$_REQUEST['slide_position2'],
							$_REQUEST['slide_position3'],
							$_REQUEST['slide_position4'],
							$_REQUEST['slide_position5'],
							$_REQUEST['slide_position6'],
							$_REQUEST['slide_position7'],
							$_REQUEST['color_position8']
							
							));
		$success_message = 'updated successfully';
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}
}

?>
		

<?php
// // SELECT To Preview 
$stmt = $con->prepare("SELECT *  FROM pgw_customize WHERE 
														position_id1=1 AND 
														position_id2=2 AND 
														position_id3=3 AND 
														position_id4=4 AND 
														position_id5=5 AND 
														position_id6=6 AND 
														position_id7=7 AND
														color_id8=8
														");

$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['slide_position1']; // Position
	$row['slide_position2']; // List display
	$row['slide_position3']; // displayControls
	$row['slide_position4']; // transitionEffect
	$row['slide_position5']; // selectionMode
	$row['slide_position6']; // pgw_slider_slideshow
	$row['slide_position7']; // Number of post / slide
	$row['color_position8']; // Color Picker position 1
}

?>



<!-- file system and custom.css will update dynamicaly -->
<?php
$filename="css/customize.css";
$filehandle = fopen($filename, 'w') or die ("can't open the file");
$data="

.pgwSlider, .pgwSlideshow, .ps-list{background-color:$row[color_position8] !important;}

";
fwrite($filehandle, $data);

fclose($filehandle);


?>

<!-- file system and custom.js will update dynamicaly -->
<?php
$filename="js/customize.js";
$filehandle = fopen($filename, 'w') or die ("can't open the file");
$data="
        //Color Picker Start 
		jQuery(document).ready(function(){
		   jQuery('.color_picker').spectrum({

			// Options
			color: '$row[color_position8]', // true or false
			flat: false,
			showInput: true,
			allowEmpty: true,
			showButtons: true,
			clickoutFiresChange: true,
			showInitial: true,
			showPalette: true,
			showPaletteOnly: false,
			hideAfterPaletteSelect: false,
			togglePalette: true,
			togglePaletteOnly: false,
			showSelectionPalette: true,
			localStorageKey: false,
			appendTo: 'body',
			maxSelectionSize: 7,
			cancelText: 'Cancel',
			chooseText: 'Choose',
			togglePaletteMoreText: 'more',
			togglePaletteLessText: 'less',
			clearText: 'Clear Color Selection',
			noColorSelectedText: 'No Color Selected',
			preferredFormat: 'hex',
			className: '', // Deprecated - use containerClassName and replacerClassName instead.
			containerClassName: '',
			replacerClassName: '',
			showAlpha: true,
			theme: 'sp-light',
			palette: [
				['#000','#444','#666','#999','#ccc','#eee','#f3f3f3','#fff'],
				['#f00','#f90','#ff0','#0f0','#0ff','#00f','#90f','#f0f'],
				['#f4cccc','#fce5cd','#fff2cc','#d9ead3','#d0e0e3','#cfe2f3','#d9d2e9','#ead1dc'],
				['#ea9999','#f9cb9c','#ffe599','#b6d7a8','#a2c4c9','#9fc5e8','#b4a7d6','#d5a6bd'],
				['#e06666','#f6b26b','#ffd966','#93c47d','#76a5af','#6fa8dc','#8e7cc3','#c27ba0'],
				['#c00','#e69138','#f1c232','#6aa84f','#45818e','#3d85c6','#674ea7','#a64d79'],
				['#900','#b45f06','#bf9000','#38761d','#134f5c','#0b5394','#351c75','#741b47'],
				['#600','#783f04','#7f6000','#274e13','#0c343d','#073763','#20124d','#4c1130'],
			],
			selectionPalette: [],
			disabled: false,
			offset: null
			
			
			   });
		   
		});
		//color picker end
		
		// pgwslider and pgwslideshow start
	   jQuery(document).ready(function($){
			 $('.$row[slide_position6]').$row[slide_position6]({
					mainClassName : '$row[slide_position6]',
					listPosition : '$row[slide_position1]',
					selectionMode : '$row[slide_position5]',
					transitionEffect : '$row[slide_position4]',
					autoSlide : true,
					displayList : $row[slide_position2],
					displayControls : $row[slide_position3],
					touchControls : true,
					verticalCentering : false,
					adaptiveHeight : false,
					maxHeight : null,
					beforeSlide : null,
					afterSlide : null,
					adaptiveDuration : 200,
					transitionDuration : 500,
					intervalDuration : 3000
				 
			 });

	   });
		
		// pgwslider and pgwslideshow end
		

";
fwrite($filehandle, $data);

fclose($filehandle);


?>




	
	<form  class="pgw_customize_select" action="" method="post" enctype="multipart/form-data">

		<table class="form-table"> <!-- here class "form-table" is wordpress class-->
		
		     <!-- Position Items -->
			 <tr>
			  <td>
<?php if(isset($success_message)){echo '<h2 style="color:#9EDA45">'.ucwords($success_message).'</h2>';};?>
<?php if(isset($error_message)){echo '<h2 style="color:red">'.ucwords($error_message).'</h2>';};?>
			  </td>
			 </tr>
			<tr>
				<td><h1>Customize Slider</h1></td>
			</tr>
			<tr>
				<td><h2>Position</h2></td>
			</tr>
			<tr>
				<td>
				SELECT ONE<br/>
				<select name="slide_position1" id="soflow">
				<option value="<?php echo $row['slide_position1'];?>"><?php echo $row['slide_position1'];?></option>
				<option value="right">right</option>
				<option value="left">left</option>
				</select>
				</td>
			</tr>
			<!-- List Items -->
			<tr>
				<td><h2>List Items</h2></td>
			</tr>
			<tr>
				<td>
				SELECT ONE<br/>
				<select name="slide_position2" id="soflow">
				<option value="<?php echo $row['slide_position2'];?>"><?php if($row['slide_position2'] == 'true'){echo 'Show-True';}else{echo 'Hide-False';}?></option>
				<option value="true">Show-True</option>
				<option value="false">Hide-False</option>
				</select><br/>
					
				</td>
			</tr>
			<!-- List Items -->
			<tr>
				<td><h2>DisplayControls Items</h2></td>
			</tr>
			<tr>
				<td>
				SELECT ONE<br/>
				<select name="slide_position3" id="soflow">
				<option value="<?php echo $row['slide_position3'];?>"><?php if($row['slide_position3'] == 'true'){echo 'Show-True';}else{echo 'Hide-False';}?></option>
				<option value="true">Show-True</option>
				<option value="false">Hide-False</option>
				</select><br/>
					
				</td>
			</tr>			
			
			<!-- transitionEffect Items -->
			<tr>
				<td><h2>transitionEffect Items</h2></td>
			</tr>
			<tr>
				<td>
				SELECT ONE<br/>
				<select name="slide_position4" id="soflow">
				<option value="<?php echo $row['slide_position4'];?>"><?php echo $row['slide_position4'];?></option>
				<option value="sliding">Sliding</option>
				<option value="fading">Fading</option>
				</select><br/>
					
				</td>
			</tr>		
			
			<!-- selectionMode Items -->
			<tr>
				<td><h2>selectionMode Items</h2></td>
			</tr>
			<tr>
				<td>
				SELECT ONE<br/>
				<p>MouseOver (only active with fading transition)</p>
				<select name="slide_position5" id="soflow">
				<option value="<?php echo $row['slide_position5'];?>"><?php echo $row['slide_position5'];?></option>
				<option value="click">Click</option>
				<option value="mouseOver">MouseOver</option>
				</select><br/>
					
				</td>
			</tr>	
			
			<!-- pgw_slider_slideshow Items -->
			<tr>
				<td><h2>Pgwslider and Pgwslideshow </h2></td>
			</tr>
			<tr>
				<td>
				SELECT ONE<br/>
				<select name="slide_position6" id="soflow">
				<option value="<?php echo $row['slide_position6'];?>"><?php echo $row['slide_position6'];?></option>
				<option value="pgwSlider">pgwSlider</option>
				<option value="pgwSlideshow">pgwSlideshow</option>
				</select><br/>
					
				</td>
			</tr>	
			
			<!-- Number of post Items -->
			<tr>
				<td><h2>Number of post Items</h2></td>
			</tr>
			<tr>
				<td>
				SELECT ONE<br/>
				<select name="slide_position7" id="soflow">
				<option value="<?php echo $row['slide_position7'];?>">No of posts-<?php echo $row['slide_position7'];?></option>

				<?php
				for($i=1;$i<=$count;$i++){
					?>
					<option value="<?php echo $i;?>"><?php echo $i?></option>
					<?php
				}
				?>
				
				
				
				</select><br/>
				
					
				</td>
			</tr>
			
			<!-- Color Picker -->
			<tr>
				<td>
					<h2>Color Picker</h2>
				</td>
			</tr>
			<tr>
				<td>
				<input type="text" id="soflow" name="color_position8" value="<?php echo $row['color_position8'];?>" class="color_picker"/>

				</td>
				
			</tr>
			
			
			<tr>
			    
				<td><input type="submit" name="form1" /></td>
			</tr>
		</table>
	</form>
	
	<div class="clear" style="clear:both"></div>
<style type="text/css">
form{padding:5px 15px;text-align:center;}
</style>	

	<?php //include('pgwslider.php');?>
<?php include('footer.php');?>