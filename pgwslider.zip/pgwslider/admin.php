

<?php include('header.php');?>
<?php include('admin-menu.php');?>
<h1>Pgwslider and Pgwslideshow Dashboard</h1>
<?php include('footer.php');?>