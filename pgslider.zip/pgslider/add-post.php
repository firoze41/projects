<?php include('header.php');?>

<?php include('admin-menu.php');?>
<?php
if(isset($_REQUEST['form1'])){
	$post_title = $_REQUEST['post_title'];
	$post_location = $_REQUEST['post_location'];
	
	try{
		if(empty( $post_title )){
			throw new PDOException('Post title can\'n be empty');
		}
		if(empty( $post_location )){
			throw new PDOException('Location can\'n be empty');
		}

		
		
	// File uploads start	File uploaded php code has teken from w3school 
		
		
		// Auto increament id for image
		$sql = "SHOW TABLE STATUS LIKE 'tbl_pgslider' ";
		$stmt = $con->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetchAll();
		foreach( $result as $row ){
			$new_id = $row[10];
		}
		
		
		// Image uploading
		$target_file = $_FILES["post_image"]["name"];
		$file_basename = substr($target_file, 0, strripos($target_file, '.')); // strip extention
		$file_ext = substr($target_file, strripos($target_file, '.')); // strip name
		$f1 = $new_id. $file_ext;
		
		
		$uploadOk = 1;
		$imageFileType = pathinfo($f1,PATHINFO_EXTENSION);
		
		
		// Check if image file is a actual image or fake image

			$check = getimagesize($_FILES["post_image"]["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				echo "File is not an image.";
				$uploadOk = 0;
			}
	
			
		$image_path = 'uploads/'.$target_file;
		// Check if file already exists
		if (file_exists($image_path)) {
			echo "Sorry, file already exists.";
			$uploadOk = 0;
		}
		// Check file size
		if ($_FILES["post_image"]["size"] > 500000) {
			echo "Sorry, your file is too large.";
			$uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
		// if everything is ok, try to upload file
		} else {
				if (move_uploaded_file($_FILES["post_image"]["tmp_name"],'uploads/'. $f1)) {
					echo "The file ". basename( $_FILES["post_image"]["name"]). " has been uploaded.";
				} else {
					echo "Sorry, there was an error uploading your file.";
				}	
		}
	// File uploas end	
		

			// data select to check exists data
			$sql = "SELECT * FROM tbl_pgslider WHERE post_title=?";
			$stmt = $con -> prepare($sql);
			$stmt->execute(array($_REQUEST['post_title']));
			
			// Exists data checking
			$count = $stmt->rowCount();
			if( $count > 0 ){
				throw new PDOException("");
			}
		 
		 
		 
		 
		 
			if($uploadOk == true){
				$stmt = $con->prepare("INSERT INTO tbl_pgslider (post_title,post_location,post_image) VALUES (?,?,?)");
				$stmt->execute(array($post_title,$post_location,$f1));
				$success_message = "Data has been Inserted in database successfully";
			}
			
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}
}
?>
<?php if(isset($success_message)){echo $success_message;};?>
<?php if(isset($error_message)){echo $error_message;};?>

		<tr>
			<td><h2>Add Slider</h2></td>
		</tr>
	<form action="add-post.php" method="post" enctype="multipart/form-data">
		<table>
			<tr>
			    <td>Post Title</td>
				<td><input type="text" name="post_title" /></td>
			</tr>
			<tr>
			    <td>Location</td>
				<td><input type="text" name="post_location" /></td>
			</tr>
			<tr>
			    <td>Upload Image</td>
				<td><input type="file" name="post_image" id="post_image" /></td>
			</tr>
			<tr>
			    <td></td>
				<td><input type="submit" name="form1" /></td>
			</tr>
		</table>
	</form>
	
	<?php //include('pgwslider.php');?>	
	

<?php include('footer.php');?>