<?php
// pgw_slider_slideshow
$stmt = $con->prepare("SELECT *  FROM tbl_pgslider");
$stmt->execute();
$count = $stmt->rowCount();
?>
	
<?php
// pgw_slider_slideshow
$stmt = $con->prepare("SELECT *  FROM pgw_customize WHERE position_id6=6 AND position_id7=7");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['slide_position6'];
	$row['slide_position7'];
}
?>

	<div id="pgslider">
		<ul class="<?php echo $row['slide_position6'];?>">
<?php
			/* ===================== Nomber of post Code Starts ================== */

			$limit = $row['slide_position7']; //how many items to show 
			
			$statement = $con->prepare("SELECT * FROM tbl_pgslider  ORDER BY post_id ASC LIMIT $limit");
			$statement->execute();
			$result = $statement->fetchAll(PDO::FETCH_ASSOC);
			

			/* ===================== Nomber of post Code Ends ================== */	
		 if($count > 0){
			foreach($result as $row){
			 ?>
			 
			 <?php
			// Extract image name 
			$text_extract = substr($row['post_image'], 0, strripos($row['post_image'], '.')); // strip extention
			$substr1 = substr($text_extract,0,1);
			 ?>
			 
			 <li><img src="uploads/<?php echo $row['post_image'];?>" alt="<?php echo $row['post_location'];?>" data-description="<?php echo $row['post_title'];?>"></li>
			 <?php
		 }
		 }
		 
		 else{
			for($j=1;$j<=5;$j++){ 
			?>
			<li><img src="images/image<?php echo $j;?>.jpg" alt="your location" data-description="default title" /></li>
			<?php
			}
		 }
		 ?>
		
		</ul>
	</div>
	