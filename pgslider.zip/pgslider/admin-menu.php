<fieldset>
	<div class="menu_area">
		<ul>
			<li><a href="index.php" target="_blank">Visit pgslider</a></li>
			<li><a href="add-post.php">Add Slider</a></li>
			<li><a href="post-update.php">Update/Delete</a></li>
			<li><a href="customize.php">Customize Slider</a></li>
		</ul>
	</div>
	<style type="text/css">
	ul{margin:0;padding:0;list-style:none;}
	ul li{display:inline}
	ul li a{display:inline-block;text-decoration:none;padding:10px}
	ul li a:hover{background-color:#DFDFDF}
	</style>
</fieldset>