<?php include('config.php');?>
<?php
$stmt = $con->prepare("SELECT * FROM tbl_header_text WHERE post_id=1");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['post_description'];
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Blog Design</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">


    <link href="images/photo1.jpg" rel="icon" type="image/png" />
	<link rel="stylesheet" href="css/contact.css"/>
	<link rel="stylesheet" href="css/uikit.min.css"/>
	<link rel="stylesheet" href="css/slidenav.almost-flat.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/pagination.css" />
		<!-- Latest compiled and minified CSS -->

	<link rel="stylesheet" type="text/css" href="style.css" />

</head>

<body>

	<div id="header">
		<span class="logo">
		<h2><?php 
		if($row['post_description'] == true){echo $row['post_description'];}else{
			echo 'blog about web design';
		}?></h2></span>	
		<ul id="menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="about.php">About Me</a></li>
			<li><a href="photo.php">Photos</a></li>
			<li><a href="portfolio.php">Portfolio</a></li>
			<li><a href="friend.php">Friends</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="admin/login.php">Login</a></li>
		</ul>
		<img src="images/spacer.gif" alt="setalpm" width="120" height="120" border="0" usemap="#Map" class="rss" />
        <map name="Map">
          <area shape="circle" coords="60,60,63" href="#">
      </map>

	</div>

	
