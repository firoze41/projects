	<?php include('config.php');?>	

		<div id="sidebar">

		    <div id="search">
<?php


$stmt = $con->prepare("SELECT * FROM 	register_table,tbl_category,tbl_comment,tbl_footer,tbl_header_text,tbl_post,tbl_tag");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['post_title'];
	
}

?>
<?php			
if(isset($_REQUEST['search'])){
	echo $row['post_title'];
}			
?>			   <form action="" method="post">
					<input type="text"   placeholder="Search"/> 
					<input type="submit" name="search" value="" class="search_bg"/>	
				</form>	
<style type="text/css">
.search{position:relative;}
.search_bg{
	background:url(images/go.gif) no-repeat;
	width:26px !important;
	height:26px !important;
	position:absolute;
	right:87px;
	cursor:pointer;
	}
</style>			
												
			</div>
			<div class="list">
			<?php 

				$stmt = $con->prepare("SELECT * FROM tbl_category cat_id");
				$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
				foreach($result as $row){
						if($row['cat_id'] == true){
						echo '<h2>CATEGORIES</h2>';
						break;
						}
						if($row['cat_id'] == false){
							echo 'No Category Items';
							break;
						}
					
				}
			?>
				
				<ul>
				<?php
				$stmt = $con->prepare("SELECT * FROM tbl_category ORDER BY cat_name ASC");
				$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
				foreach($result as $row){
					?>
					<li><a href="single-category.php?id=<?php echo $row['cat_id'];?>"><?php echo $row['cat_name'];?></a></li>
					<?php
					
				}
				?>
				</ul>
				<h2>ARCHIEVES</h2>
				
				<?php
				$sql = "SELECT distinct( post_date ) FROM tbl_post ORDER BY post_date DESC"; 
				$stmt = $con->prepare($sql);
				$stmt->execute();
				
				$i=0;
				while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
					$i++;
					 //2016-07-02 12:14:23				
					$ym = substr($row['post_date'],0,7);	
					$arr_date[$i] = $ym;
				}
				$result = array_unique($arr_date); // Same items will show only one or Duplicate items Remove
			    $final_val = implode(',',$result); // data will show as an array
 				$final_arr_date = explode(',',$final_val); // array will desploy / erase
				$final_arr_date_count = count($final_arr_date); // How many date will show that count

				?>
				
				<ul>
				<?php
				for($i=0;$i<$final_arr_date_count;$i++){
					//echo $final_arr_date[$i].'<br />'; 
					
									//2016-09
					$month = substr($final_arr_date[$i],5,2);
				    $year = substr($final_arr_date[$i],0,4);
					
					// Make condition
					if($month == '01'){$month_full = 'January';}
					if($month == '02'){$month_full = 'February';}
					if($month == '03'){$month_full = 'March';}
					if($month == '04'){$month_full = 'April';}
					if($month == '05'){$month_full = 'May';}
					if($month == '06'){$month_full = 'June';}
					if($month == '07'){$month_full = 'July';}
					if($month == '08'){$month_full = 'August';}
					if($month == '09'){$month_full = 'September';}
					if($month == '10'){$month_full = 'Octomber';}
					if($month == '11'){$month_full = 'November';}
					if($month == '12'){$month_full = 'December';}

					?>
					<li><a href="archive.php?date=<?php echo $final_arr_date[$i];?>"><?php echo $month_full.' '.$year;?></a></li>
					<?php
				}
				?>
				</ul>
			</div>
		</div>
	</div> <!-- This div from post.php and last div of <div class="content"> -->