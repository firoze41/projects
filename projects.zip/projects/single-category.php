
<?php include('config.php');?>
<?php include('header.php');?>


<?php
if(!isset($_REQUEST['id'])){
	header('location:index.php');
}
 else{
	$id = $_REQUEST['id'];
	
} 
?>

<div class="content"> <!-- This div has closed to sidebar.php -->
		<div id="posts">
		<?php
			/* ===================== Pagination Code Starts ================== */
			$adjacents = 7;
										
					
			$statement = $con->prepare("SELECT * FROM tbl_post WHERE cat_id=? ORDER BY cat_id DESC");
			$statement->execute(array($id));
			$total_pages = $statement->rowCount();
							
			
			$targetpage = $_SERVER['PHP_SELF'];   //your file name  (the name of this file)
			$limit = 1;                                 //how many items to show per page
			$page = @$_GET['page'];
			if($page) 
				$start = ($page - 1) * $limit;          //first item to display on this page
			else
				$start = 0;
			
						
			$statement = $con->prepare("SELECT * FROM tbl_post WHERE cat_id=? ORDER BY post_id DESC LIMIT $start, $limit");
			$statement->execute(array($id));
			$result = $statement->fetchAll(PDO::FETCH_ASSOC);
			
			
			if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
			$prev = $page - 1;                          //previous page is page - 1
			$next = $page + 1;                          //next page is page + 1
			$lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
			$lpm1 = $lastpage - 1;   
			$pagination = "";
			if($lastpage > 1)
			{   
				$pagination .= "<div class=\"pagination\">";
				if ($page > 1) 
					$pagination.= "<a href=\"$targetpage?id=$id&page=$prev\">&#171; previous</a>";
				else
					$pagination.= "<span class=\"disabled\">&#171; previous</span>";    
				if ($lastpage < 7 + ($adjacents * 2))   //not enough pages to bother breaking it up
				{   
					for ($counter = 1; $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?id=$id&page=$counter\">$counter</a>";                 
					}
				}
				elseif($lastpage > 5 + ($adjacents * 2))    //enough pages to hide some
				{
					if($page < 1 + ($adjacents * 2))        
					{
						for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
						{
							if ($counter == $page)
								$pagination.= "<span class=\"current\">$counter</span>";
							else
								$pagination.= "<a href=\"$targetpage?id=$id&page=$counter\">$counter</a>";                 
						}
						$pagination.= "...";
						$pagination.= "<a href=\"$targetpage?id=$id&page=$lpm1\">$lpm1</a>";
						$pagination.= "<a href=\"$targetpage?id=$id&page=$lastpage\">$lastpage</a>";       
					}
					elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
					{
						$pagination.= "<a href=\"$targetpage?id=$id&page=1\">1</a>";
						$pagination.= "<a href=\"$targetpage?id=$id&page=2\">2</a>";
						$pagination.= "...";
						for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<span class=\"current\">$counter</span>";
							else
								$pagination.= "<a href=\"$targetpage?id=$id&page=$counter\">$counter</a>";                 
						}
						$pagination.= "...";
						$pagination.= "<a href=\"$targetpage?id=$id&page=$lpm1\">$lpm1</a>";
						$pagination.= "<a href=\"$targetpage?id=$id&page=$lastpage\">$lastpage</a>";       
					}
					else
					{
						$pagination.= "<a href=\"$targetpage?id=$id&page=1\">1</a>";
						$pagination.= "<a href=\"$targetpage?id=$id&page=2\">2</a>";
						$pagination.= "...";
						for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<span class=\"current\">$counter</span>";
							else
								$pagination.= "<a href=\"$targetpage?id=$id&page=$counter\">$counter</a>";                 
						}
					}
				}
				if ($page < $counter - 1) 
					$pagination.= "<a href=\"$targetpage?id=$id&page=$next\">next &#187;</a>";
				else
					$pagination.= "<span class=\"disabled\">next &#187;</span>";
				$pagination.= "</div>\n";       
			}
			/* ===================== Pagination Code Ends ================== */	

		if($total_pages > 0){
		foreach($result as $row){
			
			$substr_id = substr($row['post_id'],0,7);

			?>
			<div class="post">
				<h2><?php echo $row['post_title'];?></h2>
				<div>
					<span class="date">				
						<?php 
						

						
 						$post_id = $row['post_id'];
						
						        $day = substr($post_id,8,2);
							  $month = substr($post_id,5,2); 
							  //2016-07-02 12:14:23
							
							if($month=='01') {$month="Jan";}
							if($month=='02') {$month="Feb";}
							if($month=='03') {$month="Mar";}
							if($month=='04') {$month="Apr";}
							if($month=='05') {$month="May";}
							if($month=='06') {$month="Jun";}
							if($month=='07') {$month="Jul";}
							if($month=='08') {$month="Aug";}
							if($month=='09') {$month="Sep";}
							if($month=='10') {$month="Oct";}
							if($month=='11') {$month="Nov";}
							if($month=='12') {$month="Dec";}
							echo $month.' '.$day; 
							
/* 							echo substr('hello world',5,2); // here 5 will deduct from left site without space and 2 will count/display in next part then other will less so here will display only "wo" from "hello world" */
							
						?>
					</span>
					<span class="categories tags">Tags: 						
						<?php
						// This is tags
						$arr = explode(",",$row['tag_id']);
						$count_arr = count($arr);
						$k=0;
						for($j=0;$j<$count_arr;$j++)
						{
							
							$statement1 = $con -> prepare("SELECT * FROM tbl_tag WHERE tag_id=?");
							$statement1->execute(array($arr[$j]));
							$result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
							foreach($result1 as $row1)
							{
								$arr1[$k] = $row1['tag_name'];
							}
							$k++;
						}
						$tag_names = implode(",",$arr1);
						
						?><a href=""><?php echo $tag_names;?></a><?php
						
						?>
					</span>
				</div>
				<div class="description">
					<p><img src="uploads/<?php echo $row['post_image'];?>" alt="" width="239" />
					<?php 
					// count first 200 words(space) into a string ( explode and implode )  and then other will not show
					$slice = explode(' ',$row['post_description']);
					$first_part = implode(' ',array_slice($slice,0,200));
					
					echo $first_part;
					
					?>
					</p>
				</div>
					<p class="comments">Comments - <a href="single.php?id=<?php echo $row['post_id'];?>" target="_blank">
					<?php
					$stmt = $con->prepare("SELECT * FROM tbl_comment WHERE post_id=? AND c_active=1");
					$stmt->execute(array($row['post_id']));
					$total_count = $stmt->rowCount();
					echo $total_count;
					?>
					</a>   <span>|</span>   <a href="single.php?id=<?php echo $row['post_id'];?>" target="_blank">Continue Reading</a></p>
			</div>
			<?php
		}
		}
		else{
			echo 'Nothing Found';
		}
		

		?>
		
		
		
		
		<?php echo $pagination;?>

		</div>

<?php include_once('sidebar.php');?>
</div> 
<?php include_once('footer.php');?>
