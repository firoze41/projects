
<?php include('config.php');?>
<?php include('header.php');?>

<div class="content"> <!-- This div has closed to sidebar.php -->
<div id="posts">


<h1>Friends</h1>

</div>
<?php include_once('sidebar.php');?>
</div> 
<?php include_once('footer.php');?>
