
<?php include('config.php');?>
<?php include('header.php');?>

<div class="content"> <!-- This div has closed to sidebar.php -->
<div id="posts">


<!-- pagination-loading.php Pagination Loading display data Start -->
<div id="pageData"></div>
<span class="flash"></span>
<!-- Pagination Loading display data End -->

</div>
<?php include_once('sidebar.php');?>
</div> 
<?php include_once('footer.php');?>
