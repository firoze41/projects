<?php include('config.php');?>
<?php 
if(!isset( $_REQUEST['id'] )){
	header('location:index.php');	
}
else{
	$id = $_REQUEST['id'];
}
?>	
	


<?php include('header.php');?>
	<div id="content">

		<div id="posts">

<?php
$stmt = $con->prepare("SELECT * FROM tbl_post WHERE post_id=?");
$stmt->execute(array($id));
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['post_title'];
	$row['post_image'];
	$row['post_description'];
	$row['post_date'];
}
?>

		
		
		
			<div class="post">
				<h2><?php echo $row['post_title']?></h2>
				<div>
				<span class="date">
				<?php 
						$post_date = $row['post_date'];
							  $day = substr($post_date,0,2); 
							$month = substr($post_date,5,2);
							if($month=='01') {$month="Jan";}
							if($month=='02') {$month="Feb";}
							if($month=='03') {$month="Mar";}
							if($month=='04') {$month="Apr";}
							if($month=='05') {$month="May";}
							if($month=='06') {$month="Jun";}
							if($month=='07') {$month="Jul";}
							if($month=='08') {$month="Aug";}
							if($month=='09') {$month="Sep";}
							if($month=='10') {$month="Oct";}
							if($month=='11') {$month="Nov";}
							if($month=='12') {$month="Dec";}
							echo $month.' '.$day;
				?>
				</span>
				<span class="categories tag">Tags: 						
						<?php
						// This is tags
						$arr = explode(",",$row['tag_id']);
						$count_arr = count($arr);
						$k=0;
						for($j=0;$j<$count_arr;$j++)
						{
							
							$statement1 = $con -> prepare("SELECT * FROM tbl_tag WHERE tag_id=?");
							$statement1->execute(array($arr[$j]));
							$result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
							foreach($result1 as $row1)
							{
								$arr1[$k] = $row1['tag_name'];
							}
							$k++;
						}
						$tag_names = implode(",",$arr1);
						
						?><a href=""><?php echo $tag_names;?></a><?php
						
						?>
						</span></div>
				<div class="description article">
					<p>
					<div class="">
					<a data-uk-lightbox  href="uploads/<?php echo $row['post_image'];?>" data-lightbox-type="image" title="<?php echo $row['post_title'];?>"><img src="uploads/<?php echo $row['post_image'];?>" alt="<?php echo $row['post_title'];?>" width="100%" height="450" /></a>
					</div>
					<span><?php echo $row['post_description']?> </span></p>
				</div>
				

				
			</div>
			
			
		<!-- php script for comment -->
		<?php
		if(isset($_REQUEST['c_form1'])){
			try{
				if(empty($_REQUEST['c_name'])){
					throw new PDOException("Name can't be empty");
				}

				
				if(empty($_REQUEST['c_email'])){
					throw new PDOException("Email can't be empty");
				}
				else{
					// Email address verification
					if(filter_var($_REQUEST['c_email'],FILTER_VALIDATE_EMAIL) == false){
						throw new PDOException("Please enter a valid email address'");
					}
				}
				

				
				// Site url validation
				if($_REQUEST['c_site_url'] == false){
					echo 'optional';
				}
				else{
					if(filter_var($_REQUEST['c_site_url'],FILTER_VALIDATE_URL) == false){
						throw new PDOException("Please enter a valid url address'");
					}
				}

				// Message validation
				if(empty($_REQUEST['c_message'])){
					throw new PDOException("Name can't be empty");
				}
				else{
					if(strlen($_REQUEST['c_message']) < 130){
						throw new PDOException("Please Write comment at leat 2 lines");
					}
					elseif(strlen($_REQUEST['c_message']) > 1000){
						throw new PDOException("Please Write comment under 300 words");
					}
				}
				
				// captcha validation
				if(empty($_REQUEST['6_letters_code'] ) ||
				  strcasecmp($_REQUEST['6_letters_code'], $_POST['6_letters_code']) != 0)
				{
				//Note: the captcha code is compared case insensitively.
				//if you want case sensitive match, update the check above to
				// strcmp()
					
					throw new PDOException("\n The captcha code does not match!");
				}
				
				
				
				
				// data select to check exists data
				$sql = "SELECT * FROM tbl_comment WHERE c_message=?";
				$stmt = $con -> prepare($sql);
				$stmt->execute(array($_REQUEST['c_message']));
				
				// Exists data checking
				$total = $stmt->rowCount();
				if( $total > 0 ){
					throw new PDOException("");
				}
				
				
				// data insert into tbl_comment
				$c_date = date('Y-m-d');
				$c_active = 0;
				$stmt = $con->prepare("INSERT INTO tbl_comment (c_name,c_email,c_site_url,c_message,c_date,post_id,c_active)VALUES(?,?,?,?,?,?,?)");
				$stmt->execute([($_REQUEST['c_name']),($_REQUEST['c_email']),($_REQUEST['c_site_url']),($_REQUEST['c_message']),($c_date),($id),($c_active)]);
				$success_message = 'All data has been saved succussfully';
					

			}
			catch(PDOException $e){
				$error_message = $e->getMessage();
			}
		}
		?>
			
			<div id="comments">
			<div class="">
				<?php
				$stmt = $con->prepare("SELECT * FROM tbl_comment WHERE c_active=1 AND post_id=?");
				$stmt->execute(array($id));
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
				foreach($result as $row){
					
					if($row['c_active'] == 1){ 
					?>
					<img src="images/title3.gif" alt="" width="216" height="39" /><br />
					<?php 
					break;
				    }
				}
				?>
				
				
				<?php
				// Data preview from tbl_post
				$stmt = $con->prepare("SELECT * FROM tbl_comment WHERE c_active=1 AND post_id=? ORDER BY comment_id ASC");
				$stmt->execute(array($id));
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
				$i=0;
				foreach($result as $row){
				?>
				
				<div class="comment">
					<div class="avatar">
					
					<?php 
					    $gravatarMd5 = md5($row['c_email']);
						//$gravatarMd5 = "";   // when no gravatar is found
					?>
					<a href="<?php echo $row['c_site_url'];?>" target="_blank"><img src="http://www.gravatar.com/avatar/<?php echo urlencode($gravatarMd5); ?>" alt="" width="80" height="80"></a> <br>
				
				<!--<img src="images/avatar1.jpg" alt="" width="80" height="80" /><br />-->
						<span><?php echo $row['c_name'];?></span><br />
							<?php 
							$post_date = $row['c_date'];
							$day = substr($post_date,8,2);
							$month = substr($post_date,5,2); 
							$year = substr($post_date,0,4); 
								  //2016-07-02 12:14:23
								
								if($month == '01'){$month_full = 'January';}
								if($month == '02'){$month_full = 'February';}
								if($month == '03'){$month_full = 'March';}
								if($month == '04'){$month_full = 'April';}
								if($month == '05'){$month_full = 'May';}
								if($month == '06'){$month_full = 'June';}
								if($month == '07'){$month_full = 'July';}
								if($month == '08'){$month_full = 'August';}
								if($month == '09'){$month_full = 'September';}
								if($month == '10'){$month_full = 'Octomber';}
								if($month == '11'){$month_full = 'November';}
								if($month == '12'){$month_full = 'December';}
								echo $month_full.' '.$day.' '.$year; 	
							?>
					</div>
					<p><?php echo $row['c_message'];?></p>
				</div>
				<?php	
				}	
				?>			
				</div>	
				
				
				
				<div id="add">
					<img src="images/title4.gif" alt="" width="216" height="47" class="title" /><br />
					<div class="avatar">
						<img src="images/avatar2.gif" alt="" width="80" height="80" /><br />
						<span>Name User</span><br />
						<?php echo date('M-d');?>
					</div>
					<div class="form">	

					
<?php if(isset($success_message)){ echo "<span style='padding:5px;background-color:#8DD241;color:#fff;width:100%'>$success_message</span>";};?>

<?php if(isset($error_message)){echo "<span style='padding:5px;background-color:red;color:#fff;width:100%'>$error_message</span>";};?>	
		


						<form action="single.php?id=<?php echo $id;?>" method="post" class="uk-form">
							<input type="text" name="c_name" placeholder="Name" /><br />
							<input type="text" name="c_email" placeholder="E-mail" /><br />
							<input type="text" name="c_site_url" placeholder="URL (Optional)" /><br />
							<textarea name="c_message" placeholder="Your Message..."></textarea><br />
							<!-- captcha start  -->
								<img src="captcha/captcha_code_file.php?rand=<?php echo rand(); ?>" id='captchaimg' ><br/>
								<label for='message'>Enter the code above here :</label><br/>
								<input id="6_letters_code" name="6_letters_code" type="text"><br/>
								<small>Can't read the image? click <a href='javascript: refreshCaptcha();'>here</a> to refresh</small><br/>
							<!-- captcha end  -->
							<input type="submit" name="c_form1" value=""/>
						</form>
					</div>
				</div>
			</div>
		</div>
			
		
		
		
	<?php include('sidebar.php');?>
	</div>
		
<?php include('footer.php');?>	
	
	
