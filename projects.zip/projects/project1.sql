-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2016 at 06:53 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project1`
--

-- --------------------------------------------------------

--
-- Table structure for table `register_table`
--

CREATE TABLE `register_table` (
  `id` int(6) UNSIGNED NOT NULL,
  `firstname` varchar(300) NOT NULL,
  `lastname` varchar(300) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register_table`
--

INSERT INTO `register_table` (`id`, `firstname`, `lastname`, `email`, `password`, `reg_date`) VALUES
(1, 'Firoze', 'Islam', 'rizwanhameedfiroze@gmail.com', '202cb962ac59075b964b07152d234b70', '2016-07-17 18:47:27'),
(2, 'Firoze', 'Islam', 'hello@gmail.com', '202cb962ac59075b964b07152d234b70', '2016-06-28 04:31:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cat_id` int(6) UNSIGNED NOT NULL,
  `cat_name` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `reg_date`) VALUES
(12, 'computer', '2016-06-21 06:03:13'),
(14, 'laptop', '2016-06-21 06:03:20'),
(15, 'computer2', '2016-06-21 09:01:29'),
(16, 'mobile', '2016-06-22 08:34:06'),
(17, 'desktop', '2016-06-23 08:22:07'),
(18, 'community', '2016-06-25 04:27:58');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE `tbl_comment` (
  `comment_id` int(6) UNSIGNED NOT NULL,
  `c_name` varchar(15) NOT NULL,
  `c_email` varchar(200) DEFAULT NULL,
  `c_site_url` varchar(200) DEFAULT NULL,
  `c_message` text NOT NULL,
  `c_date` varchar(20) DEFAULT NULL,
  `post_id` int(6) DEFAULT NULL,
  `c_active` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_comment`
--

INSERT INTO `tbl_comment` (`comment_id`, `c_name`, `c_email`, `c_site_url`, `c_message`, `c_date`, `post_id`, `c_active`) VALUES
(1, 'firoze', 'rizwanhameedfiroze@gmail.com', 'http://facebook.com', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '2016-07-13', 25, 1),
(2, 'rana', 'usama@gmail.com', 'http://facebook.com', '<p>known printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum&nbsp;</p>\r\n', '2016-07-17', 25, 0),
(3, 'rana', 'usama@gmail.com', 'http://facebook.com', '<p><strong>rem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It&nbsp;</p>\r\n', '2016-07-17', 25, 0),
(4, 'usama', 'hello@gmail.com', 'http://facebook.com', '<p>y of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker in</p>\r\n', '2016-07-17', 25, 0),
(5, 'usama', 'hello@gmail.com', 'http://facebook.com', 'Can you help translate XAMPP for other community members? We need your help to translate XAMPP Can you help translate XAMPP for other community members? We need your help to translate XAMPP ', '2016-07-17', 13, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_footer`
--

CREATE TABLE `tbl_footer` (
  `post_id` varchar(3) DEFAULT NULL,
  `post_description` text NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_footer`
--

INSERT INTO `tbl_footer` (`post_id`, `post_description`, `reg_date`) VALUES
('1', '<p>Footer Text goes here....</p>', '2016-07-01 01:16:27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_header_text`
--

CREATE TABLE `tbl_header_text` (
  `post_id` varchar(3) DEFAULT NULL,
  `post_description` varchar(32) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_header_text`
--

INSERT INTO `tbl_header_text` (`post_id`, `post_description`, `reg_date`) VALUES
('1', '<p>ver since the 1500s, when</p>', '2016-07-05 14:44:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `post_id` int(6) UNSIGNED NOT NULL,
  `post_title` varchar(300) NOT NULL,
  `post_description` text NOT NULL,
  `cat_id` varchar(300) NOT NULL,
  `tag_id` varchar(300) NOT NULL,
  `post_image` varchar(300) NOT NULL,
  `post_month` varchar(2) NOT NULL,
  `post_year` varchar(4) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reg_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`post_id`, `post_title`, `post_description`, `cat_id`, `tag_id`, `post_image`, `post_month`, `post_year`, `post_date`, `reg_date`) VALUES
(13, 'Contribute to XAMPP translation', '<p>Can you help translate XAMPP for other community members? We need your help to translate XAMPP into different languages. We have set up a site,&nbsp;<a href="https://translate.apachefriends.org/">translate.apachefriends.org</a>, where users can contribute translations.Can you help translate XAMPP for other community members? We need your help to translate XAMPP into different languages. We have set up a site,&nbsp;<a href="https://translate.apachefriends.org/">translate.apachefriends.org</a>, where users can</p>\r\n', '12', '7,5,1', '13.jpg', '10', '2015', '2015-10-01 03:15:56', '0000-00-00 00:00:00'),
(14, 'Install applications on XAMPP using Bitnami Install applications on XAMPP using Bitnami Install applications on XAMPP using Bitnami ', '<p>Apache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firoze&nbsp;Apache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firoze</p>\r\n', '18', '7,4', '14.jpeg', '10', '2015', '2015-10-01 03:22:34', '0000-00-00 00:00:00'),
(15, 'Admin Panel Dashboard', '<p>XAMPP has been around for more than 10 years &ndash; there is a huge community behind it. You can get involved by joining our&nbsp;<a href="https://community.apachefriends.org/">Forums</a>, adding yourself to the&nbsp;<a href="https://www.apachefriends.org/community.html#mailing_list">Mailing List</a>, and liking us on&nbsp;<a href="https://www.facebook.com/we.are.xampp">Facebook</a>, following our exploits on&nbsp;<a href="https://twitter.com/apachefriends">Twitter</a>, or adding us to your&nbsp;<a href="https://plus.google.com/+xampp/posts">Google+</a>&nbsp;circles.</p>\r\n', '12', '5', '15.png', '09', '2014', '2016-07-05 03:10:24', '0000-00-00 00:00:00'),
(16, 'Admin Panel Dashboard', 'We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.We need your help to translate XAMPP into different languages. We have set up a sitewhere users can contribute translations.\r\n', '17', '2,6,4', '16.png', '10', '2016', '2016-07-05 03:10:29', '0000-00-00 00:00:00'),
(17, 'rRetro Photos', '<p>Apache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firoze&nbsp;Apache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firozeApache Friends and Bitnami are cooperating to make dozens of open source applications available on XAMPP, for free. Bitnami-packaged applications include Wordpress, Drupal, Joomla! and dozens of others and can be deployed with one-click installers. Visit the firoze</p>\r\n', '14', '7,1,6', '17.png', '09', '2014', '2014-09-01 03:24:54', '0000-00-00 00:00:00'),
(18, 'Welcome to XAMPP for Windows 7.0.4', '<p>You have successfully installed XAMPP on this system! Now you can start using Apache, MariaDB, PHP and other components. You can find more info in the&nbsp;<a href="http://localhost/dashboard/faq.html">FAQs</a>&nbsp;section or check the&nbsp;<a href="http://localhost/dashboard/howto.html">HOW-TO Guides</a>&nbsp;for getting started with PHP applications.</p>\r\n\r\n<p>Start the XAMPP Control Panel to check the server status.</p>\r\n\r\n<p>You have successfully installed XAMPP on this system! Now you can start using Apache, MariaDB, PHP and other components. You can find more info in the&nbsp;<a href="http://localhost/dashboard/faq.html">FAQs</a>&nbsp;section or check the&nbsp;<a href="http://localhost/dashboard/howto.html">HOW-TO Guides</a>&nbsp;for getting started with PHP applications.</p>\r\n\r\n<p>Start the XAMPP Control Panel to check the server status.</p>\r\n', '15', '2,6,4', '18.png', '09', '2014', '2014-09-01 03:25:10', '0000-00-00 00:00:00'),
(19, 'translate.apachefriends.org.', '<p>You have successfully installed XAMPP on this system! Now you can start using Apache, MariaDB, PHP and other components. You can find more info in the&nbsp;<a href="http://localhost/dashboard/faq.html">FAQs</a>&nbsp;section or check the&nbsp;<a href="http://localhost/dashboard/howto.html">HOW-TO Guides</a>&nbsp;for getting started with PHP applications.</p>\r\n\r\n<p>You have successfully installed XAMPP on this system! Now you can start using Apache, MariaDB, PHP and other components. You can find more info in the&nbsp;<a href="http://localhost/dashboard/faq.html">FAQs</a>&nbsp;section or check the&nbsp;<a href="http://localhost/dashboard/howto.html">HOW-TO Guides</a>&nbsp;for getting started with PHP applications.</p>\r\n\r\n<p>Start the XAMPP Control Panel to check the server status.</p>\r\n', '12', '7,5,1,2,6,4', '19.png', '08', '2013', '2013-08-01 03:25:49', '0000-00-00 00:00:00'),
(20, 'How can I install a server as a service?', '<p>Each server in XAMPP you can install also as Windows service. You can also install it from the XAMPP Control Panel. In this case it is necessary to run the scripts or the Control Panel with Administrator privileges.</p>\r\n\r\n<p>Apache service install: \\xampp\\apache\\apache_installservice.bat</p>\r\n\r\n<p>Apache service uninstall: \\xampp\\apache\\apache_uninstallservice.bat</p>\r\n\r\n<p>MySQL service install: \\xampp\\mysql\\mysql_installservice.bat</p>\r\n\r\n<p>MySQL service uninstall: \\xampp\\mysql\\mysql_uninstallservice.bat</p>\r\n\r\n<p>FileZilla service (un)install: \\xampp\\filezilla_setup.bat</p>\r\n\r\n<p>Mercury: No service installation available</p>\r\n', '15', '7,1,6', '20.jpg', '08', '2013', '2013-08-01 03:25:57', '0000-00-00 00:00:00'),
(21, 'Is XAMPP production ready?', '<p>All points can be a huge security risk. Especially if XAMPP is accessible via network and people outside your LAN. It can also help to use a firewall or a (NAT) router. In case of a router or firewall, your PC is normally not accessible via network. It is up to you to fix these problems. As a small help there is the &quot;XAMPP Security console&quot;.</p>\r\n\r\n<p>Please secure XAMPP before publishing anything online. A firewall or an external router are only sufficient for low levels of security. For slightly more security, you can run the &quot;XAMPP Security console&quot; and assign passwords.</p>\r\n', '18', '5,6,4', '21.jpg', '06', '2012', '2012-06-01 03:26:36', '0000-00-00 00:00:00'),
(22, 'Here a list of missing security in XAMPP:', '<ol>\r\n	<li>The MySQL administrator (root) has no password.</li>\r\n	<li>The MySQL daemon is accessible via network.</li>\r\n	<li>ProFTPD uses the password &quot;lampp&quot; for user &quot;daemon&quot;.</li>\r\n	<li>PhpMyAdmin is accessible via network.</li>\r\n	<li>The XAMPP demopage is accessible via network.</li>\r\n	<li>The default users of Mercury and FileZilla are known.</li>\r\n</ol>\r\n', '17', '2,4', '22.jpg', '06', '2012', '2012-06-01 03:26:43', '0000-00-00 00:00:00'),
(23, ' IMAP support for PHP ', '<p>As default, the IMAP support for PHP is deactivated in XAMPP due to some mysterious initialization errors with some home versions like Windows 98. If you work with NT systems, you can open the file &quot;\\xampp\\php\\php.ini&quot; to activate the php exstension by removing the beginning semicolon at the line &quot;;extension=php_imap.dll&quot;. It should be:</p>\r\n', '16', '7,2,4', '23.jpg', '06', '2012', '2012-06-01 03:26:53', '0000-00-00 00:00:00'),
(24, 'Can I delete the ', '<p>It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.It&#39;s better not to. The scripts here are still needed for all additional packages (add-ons) and upgrades of XAMPP.</p>\r\n', '17', '7,1,2', '24.jpg', '02', '2009', '2009-02-01 03:27:48', '0000-00-00 00:00:00'),
(25, 'Lorem Ipsum', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '14', '2,6,4', '25.jpg', '07', '2016', '2016-07-05 03:07:56', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tag`
--

CREATE TABLE `tbl_tag` (
  `tag_id` int(6) UNSIGNED NOT NULL,
  `tag_name` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tag`
--

INSERT INTO `tbl_tag` (`tag_id`, `tag_name`, `reg_date`) VALUES
(1, 'keyboard', '2016-06-19 16:48:37'),
(2, 'microphone', '2016-06-19 16:48:41'),
(4, 'mouse', '2016-06-19 17:00:09'),
(5, 'computer', '2016-06-19 17:00:25'),
(6, 'monitor', '2016-06-20 05:44:57'),
(7, 'community', '2016-06-25 04:28:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register_table`
--
ALTER TABLE `register_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `tbl_tag`
--
ALTER TABLE `tbl_tag`
  ADD PRIMARY KEY (`tag_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register_table`
--
ALTER TABLE `register_table`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cat_id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  MODIFY `comment_id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `post_id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `tbl_tag`
--
ALTER TABLE `tbl_tag`
  MODIFY `tag_id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
