<?php
$servername = 'mysql16.000webhost.com';
$username = 'a3437612_p1';
$password = "firoze41";
$database = 'a3437612_p1';

try {
    $con = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connected successfully";

    }
catch(PDOException $e)
    {
    //echo "Connection failed: " . $e->getMessage();
    }

	
// Create database
try {
    $sql = "CREATE DATABASE $database";
    // use exec() because no results are returned
    $con->exec($sql);
    //echo "Database created successfully<br>";
    }
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }	
	


// Create tbl_category Table Under "project1" database
try{
	$sql = "CREATE TABLE tbl_category ( 
	cat_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	cat_name VARCHAR(300) NOT NULL,
	reg_date TIMESTAMP
	)";
// use exec() because no results are returned
    $con->exec($sql);
    //echo "Table tbl_category created successfully";
}	
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }


// Create tbl_tag Table Under "project1" database
try{
	$sql = "CREATE TABLE tbl_tag ( 
	tag_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	tag_name VARCHAR(300) NOT NULL,
	reg_date TIMESTAMP
	)";
// use exec() because no results are returned
    $con->exec($sql);
    //echo "Table tbl_tag created successfully";
}	
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }


// Create tbl_post Table Under "project1" database
try{
	$sql = "CREATE TABLE tbl_post ( 
	post_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	post_title VARCHAR(300) NOT NULL,
	post_description TEXT NOT NULL,
	cat_id VARCHAR(300) NOT NULL,
	tag_id VARCHAR(300) NOT NULL,
	post_image VARCHAR(300) NOT NULL,
	post_month VARCHAR(2) NOT NULL,
	post_year VARCHAR(4) NOT NULL,
	post_date TIMESTAMP,
	reg_date TIMESTAMP
	)";
// use exec() because no results are returned
    $con->exec($sql);
    //echo "Table tbl_post created successfully";
}	
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }


// Create register_table Table Under "project1" database

try{
	$sql = "CREATE TABLE register_table ( 
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	firstname VARCHAR(300) NOT NULL,
	lastname VARCHAR(300) NOT NULL,
	email VARCHAR(200),
	password VARCHAR(200),
	reg_date TIMESTAMP
	)";
// use exec() because no results are returned
    $con->exec($sql);
    //echo "Table register_table created successfully";
}	
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }	

// Create tbl_footer Table Under "project1" database

try{
	$sql = "CREATE TABLE tbl_footer ( 
	post_id VARCHAR(3) NULL,
	post_description TEXT NOT NULL,
	reg_date TIMESTAMP
	)";
// use exec() because no results are returned
    $con->exec($sql);
   // echo "Table tbl_footer created successfully";
   
   
   // Data insert By default and this data will insert into table only one time
   $stmt = $con->prepare("INSERT into tbl_footer (post_id,post_description) VALUES('1','<p>Footer Text goes here....</p>')");
   $stmt->execute();
   
   
}	
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }	
	
	
// Create tbl_header_text Table Under "project1" database

try{
	$sql = "CREATE TABLE tbl_header_text ( 
	post_id VARCHAR(3) NULL,
	post_description VARCHAR(32) NOT NULL,
	reg_date TIMESTAMP
	)";
// use exec() because no results are returned
    $con->exec($sql);
   // echo "Table tbl_header_text created successfully";
   
   
   // Data insert By default and this data will insert into table only one time
   $stmt = $con->prepare("INSERT into tbl_header_text (post_id,post_description) VALUES('1','<p>blog about web design
   ....</p>')");
   $stmt->execute();
   
   
}	
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }	

			

	
// Create tbl_comment Table Under "project1" database

try{
	$sql = "CREATE TABLE tbl_comment ( 
	comment_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	c_name VARCHAR(15) NOT NULL,
	c_email VARCHAR(200),
	c_site_url VARCHAR(200),
	c_message TEXT NOT NULL,
	c_date VARCHAR(20),
	post_id INT(6),
	c_active INT(6)
	)";
// use exec() because no results are returned
    $con->exec($sql);
    //echo "Table tbl_comment created successfully";
}	
catch(PDOException $e)
    {
    //echo $sql . "<br>" . $e->getMessage();
    }		

	
	


//$con = null;
?>