

<?php include('session-destroy.php');?>
		
		<h1 style="text-align:center;padding:5px;border-bottom:2px solid yellow;padding-bottom:5px;margin-bottom:5px;">Admin Panel Dashboard</h1><hr/>
		<table class="first_table">
		    <th>Home Page Options</th>
			
			<tr>
				<td><a class="admin_menu" href="../index.php" target="_blank">Visit Site</a></td>
			</tr>
			<th>Admin Part Options</th>
			<tr>
				<td><a class="admin_menu" href="admin-post.php">Add New Post</a></td>
				<td><a class="admin_menu" href="post-view.php">Post View</a></td>
				<td><a class="admin_menu" href="admin-header.php">Header Option</a></td>
				<td><a class="admin_menu" href="admin-sidebar.php">Sidebar Option</a></td>
				<td><a class="admin_menu" href="admin-footer.php">Footer Option</a></td>
			</tr>
			<th>Admin Categories & Tags</th>
			<tr>
				<td><a class="admin_menu" href="category.php">Manage Categories</a></td>
				<td><a class="admin_menu" href="tag.php">Manage Tags</a></td>
			</tr>
			<th>Admin User</th>
			<tr>
				<td><a class="admin_menu" href="logout.php">Logout</a></td>
			</tr>
			<tr>
				<td><a class="admin_menu" href="chang-password.php">Chang Password</a></td>
			</tr>
			<tr>
				<td><a class="admin_menu" href="admin-comment.php">Comments</a></td>
			</tr>
		</table>