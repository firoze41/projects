
<?php include('session-destroy.php');?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>admin-panel </title>
	<link rel="stylesheet" href="../css/uikit.min.css"/>
	<link rel="stylesheet" href="../css/slidenav.almost-flat.min.css"/>
	<link rel="stylesheet" href="../css/admin.css"/>

</head>
<body>

