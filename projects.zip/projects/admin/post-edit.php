

<?php include('session-destroy.php');?>
<?php include('../config.php');?>

<?php
// This id from post-view.php
 if(! isset($_REQUEST['id'])){
	header('Location:post-view.php');
}
else{
	$id = $_REQUEST['id'];
} 
?>
<?php
if(isset($_REQUEST['update_form'])){
	
	
	try{
		
		if(empty($_REQUEST['post_title'])){
			throw new PDOException("Title can't be empty");
		}
		if(empty($_REQUEST['ckeditor_post_description'])){
			throw new PDOException("Desctription can't be empty");
		}
		if(empty($_REQUEST['cat_id'])){
			throw new PDOException("Category name can't be empty");
		}
		if(empty($_REQUEST['tag_id'])){
			throw new PDOException("Tag name can't be empty");
		}
		
		// Creating looping for tags and seperate by array	
		$i=0;
		if(isset( $_REQUEST['tag_id'] )){
			foreach( $_REQUEST['tag_id'] as $key => $value ){
				$arr[$i] = $value;
				$i++;
			}	
			
			$tag_ids = implode(',',$arr); // seperate by array	
		}
		
        
		
		// Update tbl_post
		if(empty( $_FILES["feature_image"]["name"] )){
			
			$m = date('m');
			$y = date('Y');
			// update tbl_post without image
			$sql = "UPDATE tbl_post SET post_title=?,post_description=?,cat_id=?,tag_id=?,post_month=?,post_year=? WHERE post_id=?";
			$stmt = $con->prepare($sql);
			$stmt->execute(array( $_REQUEST['post_title'],$_REQUEST['ckeditor_post_description'],$_REQUEST['cat_id'],$tag_ids,$m,$y,$id ));
			
		}
		else{
			// Image uploading and  extracting extension and selecting
			$up_filename=$_FILES["feature_image"]["name"];
			$file_basename = substr($up_filename, 0, strripos($up_filename, '.')); // strip extention
			$file_ext = substr($up_filename, strripos($up_filename, '.')); // strip name
			$f1 = $id . $file_ext;
			
			
			
			// Get Image Size or Check Image Size
			list($width,$height,$type,$attr) = getimageSize('../uploads/'.$f1);
			
			echo 'Width Of Image: '.$width.'<br />';
			echo 'Height Of Image: '.$height.'<br />';
			echo 'Type Of Image: '.$type.'<br />';
			echo 'Attribute Of Image: '.$attr.'<br />';
			
			
			
			// define file size
			// Define File Size that User Will Upload
			// $filesize = filesize($file) * .0009765625; // kb size
			// $filesize = (filesize($file) * .0009765625) * .0009765625; // bytes to MB
			// $filesize = ((filesize($file) * .0009765625) * .0009765625) * .0009765625; // bytes to GB
			$filesize = (filesize($_FILES['feature_image']['tmp_name']) * .0009765625) * .0009765625; // bytes to MB
			
			if( ($filesize > 1) ){
				throw new PDOException ('<h3 style="color:red">'.'<br>'.'*You Have Uploaded '.$filesize. '<br>'.' *Your File Is Grater Than 1 MB'.'<br>'.'*Upload less Than 1 OR == 1  MB '.'<br>'.'</h3>'); 
			}
			
			
			
			// Image formating and checking extensions 
			if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif'))
				throw new PDOException("Only jpg, jpeg, png and gif format images are allowed to upload.");
			
			
			// Image select and delete from folder from tbl_post according to post_id and unlink / unset image path
			//and image will be replaced
			$stmt = $con->prepare("SELECT * FROM tbl_post WHERE post_id=?");
			$stmt->execute(array( $id ));
			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			foreach($result as $row){
				$real_path = "../uploads/".$row['post_image'];
				unlink($real_path);
			}

			// Where image will upload
			move_uploaded_file($_FILES["feature_image"]["tmp_name"],"../uploads/" . $f1);
			
			
			$m = date('m');
			$y = date('Y');
			// update tbl_post with image
			$sql = "UPDATE tbl_post SET post_title=?,post_description=?,post_image=?,cat_id=?,tag_id=?,post_month=?,post_year=? WHERE post_id=?";
			$stmt = $con->prepare($sql);
			$stmt->execute(array( $_REQUEST['post_title'],$_REQUEST['ckeditor_post_description'],$f1,$_REQUEST['cat_id'],$tag_ids,$m,$y,$id ));
		}

		$success_message = "Post has been updated successfully";
		
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}
}

?>



<?php
// Data displaying tbl_post
$sql = "SELECT * FROM tbl_post WHERE post_id='$id'";
$stmt = $con->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$post_title = $row['post_title'];
	$post_description = $row['post_description'];
	$cat_id = $row['cat_id'];
	$tag_id = $row['tag_id'];
	$post_image = $row['post_image'];
}
?>


<?php include('header.php');?>
	<div class="admin_area">
<?php include('common-admin.php');?>
<form action="" method="post" enctype="multipart/form-data" class="uk-form">

	<table class="last_table">
		<tr>
			<th><h3>Edit Posts</h3><hr/></th>
		</tr>
		<tr>
			<th>
<?php if(isset($error_message)){echo "<span class='error_message'>$error_message</span>";}?>
<?php if(isset($success_message)){echo "<span class='success_message'>$success_message</span>";}?>
			</th>
		</tr>
		
		<tr>
			<td>Title:</td>
			<td><input style="width:100%" type="text" name="post_title" value="<?php echo $post_title;?>" /></td><br>
			<td>Description:</td>
			<td><textarea name="ckeditor_post_description" value=""><?php echo $post_description;?></textarea></td>

			<td>
			Select A Category
			<select name="cat_id" id="form-h-s">
				<option value="">Select A Category</option>
					<?php
					// Category name will display / be selected by default according to post
					$sql ="SELECT * FROM tbl_category ORDER BY cat_name ASC";
					$stmt =  $con->prepare($sql);
					$stmt->execute();
					$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
					foreach( $result as $row ){
						
 						if( $row['cat_id'] == $cat_id )
							// here $row['cat_id'] from tbl_category and $cat_id from tbl_post
						{
							?><option value="<?php echo $row['cat_id']; ?>" selected><?php echo $row['cat_name']; ?></option><?php
						}
						else
						{
							?><option value="<?php echo $row['cat_id']; ?>"><?php echo $row['cat_name']; ?></option><?php
						} 
					
						
					}
					
					?>
										
			</select>
			</td>

			<td>
			Select A Tag&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />
				<?php
				// Tag name will display / be checked by default according to post
				$stmt = $con->prepare("SELECT * FROM tbl_tag ORDER BY tag_name");
				$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
				foreach($result as $row){
					
						$arr1 = explode(",",$tag_id);
						$count_arr = count($arr1);
						$is_there=0;
						for($j=0;$j<$count_arr;$j++)
						{
							if($arr1[$j] == $row['tag_id']){
							$is_there = 1;
							break;
							}
							
						}	
							
						if($is_there == 1){
							?>
							<input type="checkbox" name="tag_id[]" value="<?php echo $row['tag_id'];?>" checked /><span><?php echo $row['tag_name'];?></span><br />
							<?php
						}
					
						else{
							?>
							<input type="checkbox" name="tag_id[]" value="<?php echo $row['tag_id'];?>" /><span><?php echo $row['tag_name'];?></span><br />
							<?php
						}	

				}
				?>
			</td>
			
			<td>
			<a href="">
				<img style="text-align:center;" width="80" height="80" src="../uploads/<?php echo $post_image;?>" alt="" />
			</a>
				
				
				<h2>Current Feature Image Preview </h2>
			</td>	
			
			<td>Upload Feature Image 
			<input class="myButton" type="file" name="feature_image" value="Upload Image" />
			</td>	
			
			<hr/>				
			<td style="float:left;margin-top:2px">
			<input class="myButton" type="submit" name="update_form" value="Update" />
			</td>
			<td>
			<br /><br /><hr /><br />
			<a class="myButton" href="post-view.php">Cancel</a>
			</td>
			
		</tr>

		
	</table>

</form>
		
	</div>
<?php include('footer.php');?>