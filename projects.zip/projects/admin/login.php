<?php include('../config.php');?>
<?php include('admin-email.php');?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>login page</title>
<link rel="stylesheet" type="text/css" href="../css/admin.css"/>
</head>
<body>
	<div class="login_page admin_area">
	    <div class="gif_image" style="background:url(https://67.media.tumblr.com/3a1aab9c85de8210ccc53c09850c2037/tumblr_mf3g9sdMyc1qk2z5wo1_500.gif) no-repeat">
			<form action="" method="post" class="uk-form">
			
				<table>
					<h1><?php echo (strtoupper('user login'));?></h1>
					<?php
					include('admin-email.php');
					if(isset($_POST['st_submit'])){
						$e_mail = $_POST['e_mail'];
						$p_assword = $_POST['p_assword'];
						
						
					if(empty($_POST['e_mail'])) {
						echo('<span class="error_message">Email can not be empty</span><br />');
					}

					if(empty($_POST['p_assword'])) {
						echo('<span class="error_message">Password can not be empty</span>');
					}
						
						
					if( ( $e_mail == true && $p_assword == true ) ){
						
					try{
						//Select Data From MySQL // Prepare statement
						
							$stmt = $con->prepare("SELECT * FROM register_table WHERE email='$e_mail' && password='".MD5("$p_assword")."' && id=1");
							$stmt->execute();	
							
							$num = 0;
							
							$num = $stmt -> rowCount();
							
							if($num > 0) 
							{
								session_start();
								$_SESSION['email'] = $admin_email;
									header("location: index.php");
								
							}
							else
							{
								echo('<span class="error_message">Invalid Email and/or password</span>');
							}

						
					}
					catch(PDOException $e) {
						echo $error_message = $e->getMessage();
					}

					}
					$con = null;
					}
					?>
					<?php
					if(isset($error_message)){
						echo '<span class="error_message">'.$error_message.'</span>';
					}
					?>
					<tr>
						<td><input type="email" name="e_mail" placeholder="<?php echo (strtoupper('email'));?>" /></td>
					</tr>
					<tr>
						<td>
						   <input type="password" name="p_assword" placeholder="<?php echo (strtoupper('password'));?>" />
						</td>
					</tr>
					<tr>
						<td><input type="submit" name="st_submit" value="<?php echo (ucfirst('login'));?>" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo ('register.php');?>">Register</a></td>
					</tr>
				</table>
			</form>	
		
		</div>
	</div>
<script src="../js/jquery_latest.js"></script>
	<script type="text/javascript">
    // speed in milliseconds
	var scrollSpeed = 1;
	// set the default position
	var current = 0;
	// set the direction
	var direction = 'h';
	function bgscroll(){
    	// 1 pixel row at a time
	    current += 1;
	    // move the background with backgrond-position css properties
	    $('div.admin_area').css("backgroundPosition", (direction == 'h') ? current+"px 0" : "0 " + current+"px");
	}
	//Calls the scrolling function repeatedly
	 setInterval("bgscroll()", scrollSpeed);	
	</script>	
</body>
</html>