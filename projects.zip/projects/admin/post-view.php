

<?php include('session-destroy.php');?>

<?php
// This is has been set with delete link (see bottom)
if(isset( $_REQUEST['id'] )){
	$id = $_REQUEST['id'];
	

// First image will be selected from tbl_post then image will be deleted from folder	
$stmt = $con->prepare("SELECT * FROM tbl_post WHERE post_id='$id'");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$real_path = "../uploads/".$row['post_image'];
	unlink($real_path);
}


// Post delete from tbl_post from the server
$stmt = $con->prepare("DELETE FROM tbl_post WHERE post_id='$id'");
$stmt->execute();
$success_message = "Post Has been deleted successfully";
		
}
?>

<?php include('header.php');?>


	<div class="admin_area">
<?php include('common-admin.php');?>

		<form action="" method="post">
		<table class="last_table category_table table_results ajax pma_table">
		<h3 style="text-align:center;color:yellow">View All Posts</h3>
		<tr class="single_item">
		<th>Serial</th>
		<th>Title</th>
		<th>Actions</th>
		</tr>

<?php
// Data preview from tbl_post
$stmt = $con->prepare("SELECT * FROM tbl_post");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$i=0;
foreach($result as $row){
	$i++;
	?>
		<tr>
		<th><?php echo $i;?></th>
		<th>
			<?php 
			// count first 6 words(space) into a string ( explode and implode )  and then other will not show
			$slice = explode(' ',$row['post_title']);
			$first_part = implode(' ',array_slice($slice,0,6));
			echo ($first_part);
			?>
		</th>
	
		
		
		<th>
		<a  style="color:#fff" data-uk-modal title="" href="#my_id_<?php echo $i;?>">View</a>
		<!-- This is the modal -->
		<div id="my_id_<?php echo $i;?>" class="uk-modal">
			<div class="uk-modal-dialog" style="border:5px solid red">
				<a class="uk-modal-close uk-close" style="color:#fff;background:red;border-radius:36px;padding:5px;"></a>
					<div class="uk-panel-hover" style="color:#000;;padding:5px;">
						<h2><?php echo 'Post Number :'.$i;?></h2>
						<hr/>
						<h2><?php echo $row['post_title'];?></h2>
						<hr/>
						<p style="color:#000"><?php echo $row['post_description'];?></p>
						<hr/>
						<div>
						<h2>feature Image</h2>
						<img width="300" height="100" src="../uploads/<?php echo $row['post_image'];?>" alt="" />
						</div>
						
						<div class="category_tag">
						<h2>Category(s)</h2>
						<ul>
						<?php
						// Category from tbl_category
						$sql = "SELECT * FROM tbl_category WHERE cat_id=?";
						$statement = $con -> prepare($sql);
						$statement->execute(array($row['cat_id']));
						$output = $statement->fetchAll(PDO::FETCH_ASSOC);
						foreach($output as $value){
							?>
							<li><a href=""><?php echo $value['cat_name'];?></a></li>
							<?php
						}
						?>
						</ul>
						</div>
						<hr/>
						<div class="category_tag">
						<h2>Tag(s)</h2>
						<ul>
						<?php
						$arr = explode(",",$row['tag_id']);
						$count_arr = count($arr);
						$k=0;
						for($j=0;$j<$count_arr;$j++)
						{
							
							$statement1 = $con -> prepare("SELECT * FROM tbl_tag WHERE tag_id=?");
							$statement1->execute(array($arr[$j]));
							$result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
							foreach($result1 as $row1)
							{
								$arr1[$k] = $row1['tag_name'];
							}
							$k++;
						}
						$tag_names = implode(",",$arr1);
						
						?><li><a  href=""><?php echo $tag_names;?></a></li><?php
						
						?>

						</ul>
						</div>
						
					</div>
					

			</div>
		</div>
		&nbsp;/&nbsp;
		<a  style="color:#fff" href="post-edit.php?id=<?php echo $row['post_id'];?>">Edit</a>
		<!-- This id has shown in post-edit.php -->
		&nbsp;/&nbsp;
		<a  style="color:#fff"onclick="return confirmDelete();" href="post-view.php?id=<?php echo $row['post_id'];?>">Delete</a>
		<!-- This id has been shown on the top of the head in this page -->
		</th>
		</tr>
	<?php
}
?>




		

		
	</table>
	
	</form>

	</div>
<?php include('footer.php');?>