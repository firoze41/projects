
<?php include('session-destroy.php');?>
<?php include('../config.php');?>

<?php
// 
if(isset($_REQUEST['footer_form1'])){
	try{
		if(empty($_REQUEST['ckeditor_post_description'])){
			throw new PDOException ('');
		}
		// Footer text update only
		$stmt = $con->prepare("UPDATE tbl_footer SET post_description=? WHERE post_id=1");
		$stmt->execute(array( $_REQUEST['ckeditor_post_description']));
		$success_message = 'Footer Text has been updated successfully';
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}
}

?>
<?php
// data preview from tbl_footer
$sql = "SELECT * FROM tbl_footer WHERE post_id=1";
$stmt = $con->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['post_description'];
}
?>





<?php include('header.php');?>
	<div class="admin_area">
<?php include('common-admin.php');?>
		<table class="last_table">
			<tr>
				<th><h1>Footer Text Change</h1></th>
				<form action="" method="post">
					<table>
						<tr>
							<td>Footer Text</td>
							<td>
<?php if(isset($error_message)){echo "<h2 class='error_message'>$error_message</h2>";}?>
<?php if(isset($success_message)){echo "<h2 class='success_message'>$success_message</h2>";}?>
							</td>
							<td><textarea name="ckeditor_post_description" class=""><?php echo $row['post_description'];?></textarea></td>
						</tr>
						<tr>
							<td><input class="myButton" type="submit" value="Update" name="footer_form1" /></td>
						</tr>
					</table>
				</form>
			</tr>
		</table>
	</div>
<?php include('footer.php');?>