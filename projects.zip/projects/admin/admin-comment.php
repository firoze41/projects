

<?php include('../config.php');?>

<?php include('session-destroy.php');?>




<?php
// This is has been set with delete link (see bottom)
if(isset( $_REQUEST['id'] )){

	try{
	$stmt = $con->prepare("SELECT * FROM tbl_comment");
	$stmt->execute();
	$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	foreach($result as $row){	
			$row['c_active'];
			
		if($row['c_active'] == 0){
			// Comment Delete when active 0
			$stmt = $con->prepare("DELETE FROM tbl_comment WHERE post_id=? && c_active=0");
			$stmt->execute(array($_REQUEST['id']));
		}
		
	}		

	
	

	
	
	// comment update
    $stmt = $con->prepare("UPDATE tbl_comment SET c_active=1 WHERE comment_id=?");	
	$stmt->execute(array($_REQUEST['id']));
	$succuss_message = "Comment has been approved successfully....";
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}

}
?>

<?php include('header.php');?>


	<div class="admin_area">
<?php include('common-admin.php');?>



		<table class="last_table category_table table_results ajax pma_table">
		<h2 style="text-align:center;color:yellow">View All Comments</h2>
		<h3 style="text-align:center;color:yellow">All Unapproved Comments</h3>
<?php if(isset($success_message)){ echo "<span style='padding:5px;background-color:#8DD241;color:#fff;width:100%'>$success_message</span>";};?>
			
<?php if(isset($error_message)){echo "<span style='padding:5px;background-color:red;color:#fff;width:100%'>$error_message</span>";};?>	
		<tr class="single_item">
		<th>Serial</th>
		<th>Name</th>
		<th>Email</th>
		<th>Url</th>
		<th>Date</th>
		<th>Action</th>
		<th>Status</th>
		</tr>

<?php
// Data preview from tbl_post
$stmt = $con->prepare("SELECT * FROM tbl_comment WHERE c_active=0 ORDER BY comment_id DESC");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$i=0;
foreach($result as $row){
	$i++;
	?>
		<tr>
		<th><?php echo $i;?></th>
		<th><?php echo $row['c_name'];?></th>
		<th><?php echo $row['c_email'];?></th>
		<th><?php echo $row['c_site_url'];?></th>
		<th><?php echo $row['c_date'];?></th>
		<th>
		<a  style="color:#fff" onclick="return confirmDelete();" href="admin-comment.php?id=<?php echo $row['post_id'];?>*<?php echo $row['comment_id'];?>">Delete</a>
		</th>
		<th><a style="color:#fff;" href="admin-comment.php?id=<?php echo $row['comment_id'];?>">Approve</a></th>
		</tr>
	<?php
}
?>

	</table>
	
<br/><br/><br/><hr/>
	<!-- Approved comments -->
		<table class="last_table category_table table_results ajax pma_table">
		<h3 style="text-align:center;color:yellow">All Approved Comments</h3>	
		<tr class="single_item">
		<th>Serial</th>
		<th>Name</th>
		<th>Email</th>
		<th>Url</th>
		<th>Date</th>
		<th>Post Id</th>
		</tr>

<?php
// Data preview from tbl_post
$stmt = $con->prepare("SELECT * FROM tbl_comment WHERE c_active=1 ORDER BY comment_id DESC");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$i=0;
foreach($result as $row){
	$i++;
	?>
		<tr>
		<th><?php echo $i;?></th>
		<th><?php echo $row['c_name'];?></th>
		<th><?php echo $row['c_email'];?></th>
		<th><?php echo $row['c_site_url'];?></th>
		<th><?php echo $row['c_date'];?></th>
		<th>
		<?php echo $row['post_id'];?>
		</th>
		</tr>
	<?php
}
?>

	</table>
	</div>
<?php include('footer.php');?>