
<?php include('session-destroy.php');?>

<?php include('header.php');?>
	<div class="admin_area">
<?php include('common-admin.php');?>
		<table class="last_table">
			<tr>
				<th><h1>Sidebar</h1></th>
			</tr>
			<tr>
				<th><td>
				<form action="/file-upload" class="dropzone">
				  <div class="fallback">
					<input name="file" type="text" multiple />
				  </div>
				</form>
				</td></th>
				
			</tr>
		</table>
	</div>
<?php include('footer.php');?>