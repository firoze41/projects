
<?php include('session-destroy.php');?>
<?php include('../config.php');?>

<?php
if(isset($_REQUEST['ps_form1'])){
	try{
		if(empty($_REQUEST['old_ps'])){
			throw new PDOException('Old Password Can\'t be empty');
		}
		if(empty($_REQUEST['new_ps'])){
			throw new PDOException('New Password Can\'t be empty');
		}
		if(empty($_REQUEST['confirm_ps'])){
			throw new PDOException('Confirm Password Can\'t be empty');
		}
		
		// Data preview and select
		$stmt = $con->prepare("SELECT * FROM register_table WHERE id=1");
		$stmt->execute();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			
			if( ( md5($_REQUEST['old_ps']) ) != ($row['password']) ){
				throw new PDOException('Old Password is wrong');
			}
			
			if( ( $_REQUEST['new_ps'] ) != ( $_REQUEST['confirm_ps'] ) ){
				throw new PDOException('New Password AND Confirm Password Does Not Matched');
			}
			
		}
		
		
		// Update database
		$stmt = $con->prepare("UPDATE register_table SET password=? WHERE id=1");
		$stmt->execute(array( (md5($_REQUEST['new_ps'])) ));
		
		$success_message = 'Password Updated Successfully';
		
		
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}
	
}
?>


<?php include('header.php');?>
	<div class="admin_area">
<?php include('common-admin.php');?>
<h1>Chang Password</h1>
<fieldset>
<?php if(isset($error_message)){echo "<h2 style='color:red'>$error_message</h2><hr/>";}?>
<?php if(isset($success_message)){echo "<h2 style='color:#9EDA45'>$success_message</h2><hr/>";}?>
      <form action="" method="post" style="padding:10px;" class="uk-form">
      	<table>
      		<tr>
				<td>Old Password</td>
      			<td><input type="password" name="old_ps" /></td>
      		</tr>
      		<tr>
				<td>New Password</td>
      			<td><input type="password" name="new_ps" /></td>
      		</tr>
      		<tr>
				<td>Confirm Password</td>
      			<td><input type="password" name="confirm_ps" /></td>
      		</tr>
      		<tr>
      			<td><br/><input type="submit" value="Update" name="ps_form1" class="myButton" /></td>
      		</tr>
      	</table>
      </form>
</fieldset>

	</div>
<?php include('footer.php');?>