<?php include('../config.php');?>


<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>logout page</title>
<link rel="stylesheet" type="text/css" href="../css/admin.css"/>
</head>
<body>
	<div class="login_page admin_area">
		<?php
		session_start();
		session_unset();
		header("location:login.php"); 
		?>
		
	</div>
</body>
</html>