

<?php include('session-destroy.php');?>

<?php include('../config.php');?>

<?php
if(isset($_REQUEST['cat_form1'])){
	$cat_name = $_REQUEST['cat_name'];
	

try{
	
	if(empty($_REQUEST['cat_name'])) {
		throw new PDOException("Category Name can not be empty.");
	}
	
	//Select Data From MySQL to check exists data is database // Prepare statement
	$stmt = $con->prepare("SELECT * FROM tbl_category WHERE cat_name='$cat_name'");
	$stmt->execute();
	
	// Exists data cheking
	$total = $stmt->rowCount();
	if($total > 0){
		throw new PDOException("Category Name <strong><i>$cat_name</i></strong> Already Exists.");
	}
	
	// Data Insert into table
	$sql = "INSERT INTO tbl_category (cat_name)VALUES('$cat_name')";
	// use exec() because no results are returned
    $con->exec($sql);
	$success_message1 = "Category name <strong><i>$cat_name</i></strong> has been inserted successfully";
}
catch(PDOException $e)
    {
		$error_message_form1 = $e->getMessage();
    }
}
?>


<?php
// Data update
if(isset($_REQUEST['cat_form2'])){
	$cat_name = $_REQUEST['cat_name'];
	
	try{
		if(empty($_REQUEST['cat_name'])){
			throw new PDOException("Category Name can not be empty.");
		}
		
	//Select Data From MySQL to check exists data is database // Prepare statement
	$stmt = $con->prepare("SELECT * FROM tbl_category WHERE cat_name='$cat_name'");
	$stmt->execute();
	
	// Exists data cheking
	$total = $stmt->rowCount();
	if($total > 0){
		throw new PDOException("Category Name <strong><i>$cat_name</i></strong> Already Exists.");
	}	
		
		
		
	$sql = "UPDATE tbl_category SET cat_name='$cat_name' WHERE cat_id='$_REQUEST[hdn]'";
    // Prepare statement
    $stmt = $con->prepare($sql);

    // execute the query
    $stmt->execute();
	
	$success_message2 = "Category name has been updated successfully";
	}
	catch(PDOException $e){
		$error_message2 = $e->getMessage();
	}
	
}
?>


<?php
// Data delete
if(isset($_REQUEST['id'])){
	$id = $_REQUEST['id'];
	// data delete
	$sql = "DELETE FROM tbl_category WHERE cat_id='$id'";
    // Prepare statement
    $stmt = $con->prepare($sql);
	// execute the query
	$stmt->execute();
	$success_message3 = "Category name has been deleted successfully";
}



?>





<?php include('header.php');?>
	<div class="admin_area">
<?php include('common-admin.php');?>
		<table class="last_table category_table">
		<p style="background: none repeat scroll 0 0 #DDDDDD;
margin-left: 222px;
padding: 9px 239px;
width: 24%;">



<?php
if(isset($error_message_form1)) {echo "<span class='error_message'>".$error_message_form1."</span>";}
if(isset($success_message1)) {echo "<span class='success_message'>".$success_message1."</span>";}
?>
		<form class="uk-form" action="" method="post">
			Category Name 
			<br> 
			<input type="text" name="cat_name" />
			<input type="submit" value="Save" name="cat_form1" />
		</form>
		</p>
<div style="width:100%;text-align:center;">

<h2>	
View All Category Name <br />
<?php
if(isset($error_message_form2)) {echo "<span class='error_message'>".$error_message_form2."</span>";}
if(isset($success_message2)) {echo "<span class='success_message'>".$success_message2."</span>";}
if(isset($success_message3)) {echo "<span class='success_message'>".''."</span>";}
?>	
 </h2>
 </div>	
		<tr class="single_item">
		<th>Serial</th>
		<th>Category</th>
		<th>Actions</th>
		</tr>	
<?php
//Select Data From MySQL // Prepare statement
$stmt = $con->prepare("SELECT * FROM tbl_category ORDER BY cat_name ASC");
$stmt->execute();
// set the resulting array to associative
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$i=0;
foreach($result as $row) {
	$i++;
	?>
		<tr>
		<th><?php echo $i;?></th>
		<th><?php echo $row['cat_name'];?></th>
		<th>
		<!-- This is an anchor toggling the modal -->
		<a href="#id_<?php echo $i;?>" class="my_edit" data-uk-modal>Edit</a>
		<!-- This is the modal -->
		<div id="id_<?php echo $i;?>" class="uk-modal">
			<div class="uk-modal-dialog">
				<a class="uk-modal-close uk-close" style="border-radius:36px;background:red;color:#fff"></a>
				
				
				<form action="" method="post"  class="uk-form" style="background-color:#ddd;color:#000">
				<input type="hidden" name="hdn" value="<?php echo $row['cat_id']; ?>">
					<table>
						<tr>
							<td>Edit Data</td>
							<td>Category Name </td><hr/>
							<td><input name="cat_name" type="text" value="<?php echo $row['cat_name'];?>" /></td>
							<td><input type="submit" value="Update" name="cat_form2" /></td>
						</tr>
					</table>
				</form>
			</div>
		</div>
		
		&nbsp;/&nbsp;<a class="my_edit" onclick="return confirmDelete();" href="category.php?id=<?php echo $row['cat_id'];?>">Delete</a></th>
		</tr>
	<?php
}

?>		
		
		

		
	</table>

	</div>
<?php include('footer.php');?>