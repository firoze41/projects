
<?php include('session-destroy.php');?>
<?php include('../config.php');?>
<?php
if(isset($_REQUEST['tag_form1'])){
	$tag_name = $_REQUEST['tag_name'];
	
	try{
		if(empty( $_REQUEST['tag_name'] )){
			throw new PDOException("Tag name can\'t be empty");
		}
		// data select to check exists data
		$sql = "SELECT * FROM tbl_tag WHERE tag_name='$tag_name'";
		$stmt = $con -> prepare($sql);
		$stmt->execute();
		
		// Exists data checking
		$total = $stmt->rowCount();
		if( $total > 0 ){
			throw new PDOException("Tag Name <strong><i>$tag_name</i></strong> already exists");
		}
		
		
		// data insert in table
		$stmt = $con->prepare("INSERT INTO tbl_tag(tag_name)VALUES('$tag_name')");
		$stmt->execute();
		$success_message_form1 = "Tag name <strong><i>$tag_name</i></strong> has been insert successfully";
		
	}
	catch(PDOException $e){
		$error_message_form1 = $e->getMessage();
	}
}
?>

<?php
if(isset($_REQUEST['tag_form2'])){
	$tag_name = $_REQUEST['tag_name'];
	
	try{
		if(empty( $_REQUEST['tag_name'] )){
			throw new PDOException("Tag name can'\t be empty");
		}
		
		//Select Data From MySQL to check exists data is database // Prepare statement
		$stmt = $con->prepare("SELECT * FROM tbl_tag WHERE tag_name='$tag_name'");
		$stmt->execute();
		
		// Exists data cheking
		$total = $stmt->rowCount();
		if($total > 0){
			throw new PDOException("Tag Name <strong><i>$tag_name</i></strong> Already Exists.");
		}
		
		
		// data update
		$stmt = $con->prepare("UPDATE tbl_tag SET tag_name='$tag_name' WHERE tag_id='$_REQUEST[hdn]'");
		$stmt->execute();
		$success_message_form2 = "Tag name <strong><i>$tag_name</i></strong> has been updated successfully";
	}
	catch(PDOException $e){
		$error_message_form2 = $e->getMessage();
	}
}
?>

<?php
//  For data deleting

if(isset( $_REQUEST['id'] )){
	$id = $_REQUEST['id'];
	
	// Data delete from database
	$sql = "DELETE FROM tbl_tag WHERE tag_id='$id'";
	$stmt = $con->prepare($sql);
	$stmt->execute();
	
	$success_message3 = "Tag name has been deleted successfully";
}
?>





<?php include('header.php');?>
	<div class="admin_area">
<?php include('common-admin.php');?>
		<table class="last_table category_table">
		<p style="background: none repeat scroll 0 0 #DDDDDD;
margin-left: 222px;
padding: 9px 239px;
width: 24%;">

<?php if(isset($error_message_form1)){echo "<span class='error_message'>$error_message_form1</span>";}?>
<?php if(isset($success_message_form1)){echo "<span class='success_message'>$success_message_form1</span>";}?>


		<form class="uk-form" action="" method="post">
			Tag Name <br> <input type="text" name="tag_name" />
			<input type="submit" value="Save" name="tag_form1" />
		</form>
		</p>
		
		<tr>
		
<div style="width:100%;text-align:center;">

<h2>	
View All Tag Name <br />	
<?php if(isset($error_message_form2)){echo "<span class='error_message'>$error_message_form2</span>";}?>
<?php if(isset($success_message_form2)){echo "<span class='success_message'>$success_message_form2</span>";}?>
<?php if(isset($success_message3)){echo "<span class='success_message'>$success_message3</span>";}?>
 </h2>
 </div>
 
		</tr>
		<tr class="single_item">
		<th>Serial</th>
		<th>Tags</th>
		<th>Actions</th>
		</tr>
<?php
// data select to preview in back-end
$sql = "SELECT * FROM tbl_tag ORDER BY tag_name ASC";
$stmt = $con->prepare($sql);
$stmt->execute();

// set the resulting array to associative
$result = $stmt->fetchALL(PDO::FETCH_ASSOC);

$i=0;
foreach($result as $row){
	$i++;
	?>
		<tr class="">
		<th><?php echo $i;?></th>
		<th><?php echo $row['tag_name'];?></th>
		<th>
		<!-- This is an anchor toggling the modal -->
		<a href="#id_<?php echo $i;?>" class="my_edit" data-uk-modal>Edit</a>
		<!-- This is the modal -->
		<div id="id_<?php echo $i;?>" class="uk-modal">
			<div class="uk-modal-dialog">
				<a class="uk-modal-close uk-close" style="border-radius:36px;background:red;color:#fff"></a>
		
				<form action="" method="post"  class="uk-form" style="background-color:#ddd;color:#000">
				<input type="hidden" name="hdn" id="" value="<?php echo $row['tag_id'];?>" />
					<table>
						<tr>
							<td>Edit Data</td>
							<td>Tag Name </td><hr/>
							<td><input name="tag_name" type="text" value="<?php echo $row['tag_name'];?>" /></td>
							<td><input type="submit" value="Update" name="tag_form2" /></td>
						</tr>
					</table>
				</form>
			</div>
		</div>
		&nbsp;/&nbsp;<a class="my_edit" onclick="return confirmDelete();" href="tag.php?id=<?php echo $row['tag_id'];?>">Delete</a></th>
		</tr>
	<?php
}
?>		

	</table>

	</div>
<?php include('footer.php');?>