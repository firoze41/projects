

<?php include('../config.php');?>
<?php include('admin-email.php'); ?>
<?php
if(isset($_POST['st_submit'])){
	session_start();
	$f_name = $_POST['f_name'];
	$l_name = $_POST['l_name'];
	$e_mail = $_POST['e_mail'];
	$p_assword = $_POST['p_assword'];
			
try{
	if(empty($_POST['f_name'])) {
		throw new PDOException('First Name can not be empty');
	}
	if(empty($_POST['l_name'])) {
		throw new PDOException('Last Name can not be empty');
	}
	if(empty($_POST['e_mail'])) {
		throw new PDOException('Email can not be empty');
	}

	if(empty($_POST['p_assword'])) {
		throw new PDOException('Password can not be empty');
	}
	
	//Select Data From MySQL // Prepare statement
	$stmt = $con->prepare("SELECT * FROM register_table WHERE email='$e_mail'");
	$stmt->execute();
	$total = $stmt->rowCount();
	
    // Exists data cheking	
	if($total > 0){
		throw new PDOException("Email address <strong>$e_mail</strong> already exists");
	}
	
	
	// Data Insert into table
	$sql = "INSERT INTO register_table (firstname,lastname,email,password)VALUES('$f_name','$l_name','$e_mail','".MD5("$p_assword")."')";	
	// use exec() because no results are returned
	$con->exec($sql);
	$success_message = "Email address <strong>$e_mail</strong> has been inserted successfully";

}
catch(PDOException $e)
	{
	$error_message = $e->getMessage();
	}	
}


$con = null;

?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>login page</title>
<link rel="stylesheet" type="text/css" href="../css/admin.css"/>
</head>
<body>
	<div class="login_page admin_area">
	
		    <form action="" method="post" class="uk-form"> 
			<table>
				<h1><?php echo (ucwords('user registration'));?></h1>

<?php if(isset($error_message)){echo '<span class="error_message">'.$error_message.'</span>';}?>
<?php if(isset($success_message)){echo '<span class="success_message">'.$success_message.'</span>';}?>
				<tr>
					<td><input type="text" name="f_name" id="f_name" placeholder="<?php echo (ucwords('first name'));?>" /></td>
				</tr>
				<tr>
					<td><input type="text" name="l_name" id="l_name" placeholder="<?php echo (ucwords('last name'));?>" /></td>
				</tr>
				<tr>
					<td><input type="email" name="e_mail" id="e_mail" placeholder="<?php echo (ucwords('email'));?>" /></td>
				</tr>
				<tr>
					<td><input type="password" name="p_assword" id="p_assword" placeholder="<?php echo (ucwords('password'));?>" /></td>
				</tr>
				<tr>
					<td><input type="submit" name="st_submit" id="st_submit" value="<?php echo (ucwords('register'));?>" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo ('login.php');?>">Login</a></td>
				</tr>
			</table>
			</form>
		
	</div>
	
<script src="../js/jquery_latest.js"></script>
	<script type="text/javascript">
    // speed in milliseconds
	var scrollSpeed = 1;
	// set the default position
	var current = 0;
	// set the direction
	var direction = 'h';
	function bgscroll(){
    	// 1 pixel row at a time
	    current -= 1;
	    // move the background with backgrond-position css properties
	    $('div.admin_area').css("backgroundPosition", (direction == 'h') ? current+"px 0" : "0 " + current+"px");
	}
	//Calls the scrolling function repeatedly
	 setInterval("bgscroll()", scrollSpeed);	
	</script>		
</body>
</html>