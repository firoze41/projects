<?php
include('admin-email.php');
ob_start();
session_start();
if($_SESSION['email']!= $admin_email)
{
	header('location: login.php');
}
ob_end_clean();
?>