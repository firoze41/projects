
<?php include('session-destroy.php');?>
<?php include_once('../config.php');?>

<?php include('header.php');?>
	<div class="admin_area">
		<?php include('common-admin.php');?>
		<table class="last_table">
			<tr>
				<td><h1>Welcome To The New Admin Panel ! <br /> Sample Blog With PHP</h1></td>
			</tr>
		</table>
	</div>
<?php include('footer.php');?>