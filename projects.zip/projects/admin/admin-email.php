
<?php include('../config.php');?>
<?php
$admin_email = 'rizwanhameedfiroze@gmail.com'; // use your own email 
$f_name      = 'Firoze'; // use your own name 
$l_name      = 'Islam'; // use your own name 
$p_assword    = '123'; // use your own password 

?>


<?php

	
try{
	
 	//Select Data From MySQL to check exists data // Prepare statement
	$stmt = $con->prepare("SELECT * FROM register_table WHERE email='$admin_email'");
	$stmt->execute();
	$total = $stmt->rowCount();
	
    // Exists data cheking	
	if($total > 0){
		throw new PDOException("Email address <strong>$admin_email</strong> already exists");
	} 
	
	
	// Data Insert into table
	$sql = "INSERT INTO register_table (firstname,lastname,email,password)VALUES('$f_name','$l_name','$admin_email','".MD5("$p_assword")."')";	
	// use exec() because no results are returned
	$con->exec($sql);
	$success_message = "Email address <strong>$admin_email</strong> has been inserted successfully";

}
catch(PDOException $e)
	{
	//$error_message = $e->getMessage();
	}	



//$con = null;

?>