

<?php include('session-destroy.php');?>

<?php
if(isset($_REQUEST['save_form'])){
	
	
	try{
		
		if(empty($_REQUEST['post_title'])){
			throw new PDOException("Title can't be empty");
		}
		if(empty($_REQUEST['ckeditor_post_description'])){
			throw new PDOException("Desctription can't be empty");
		}
		if(empty($_REQUEST['cat_id'])){
			throw new PDOException("Category name can't be empty");
		}
		if(empty($_REQUEST['tag_id'])){
			throw new PDOException("Tag name can't be empty");
		}
		
		// Auto increament id for image
		$sql = "SHOW TABLE STATUS LIKE 'tbl_post' ";
		$stmt = $con->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetchAll();
		foreach( $result as $row ){
			$new_id = $row[10];
		}
		
		
		// Image uploading
		$up_filename=$_FILES["feature_image"]["name"];
		$file_basename = substr($up_filename, 0, strripos($up_filename, '.')); // strip extention
		$file_ext = substr($up_filename, strripos($up_filename, '.')); // strip name
		$f1 = $new_id. $file_ext;
		
		
		// define file size
		// Define File Size that User Will Upload
		// $filesize = filesize($file) * .0009765625; // kb size
		// $filesize = (filesize($file) * .0009765625) * .0009765625; // bytes to MB
		// $filesize = ((filesize($file) * .0009765625) * .0009765625) * .0009765625; // bytes to GB
		$filesize = (filesize($_FILES['feature_image']['tmp_name']) * .0009765625) * .0009765625; 
		
		if( ($filesize > 1) ){
			throw new PDOException ('<p style="color:red">'.'<br>'.'*You Have Uploaded '.$filesize. '<br>'.' *Your File Is Grater Than 1 MB'.'<br>'.'*Upload less Than 1 OR == 1  MB '.'<br>'.'</p>'); 
		}
		
		
		
		// Image format extensions checking
		if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif'))
			throw new PDOException("Only jpg, jpeg, png and gif format images are allowed to upload.");
		
		// Where image will upload
		move_uploaded_file($_FILES["feature_image"]["tmp_name"],"../uploads/" . $f1);
		
	
	// Creating looping for tags and seperate by array	
	$i=0;
	if(isset( $_REQUEST['tag_id'] )){
		foreach( $_REQUEST['tag_id'] as $key => $value ){
			$arr[$i] = $value;
			$i++;
		}	
		
		$tag_ids = implode(',',$arr); // seperate by array	
	}	
	
	
	
	// Time and timestamp
	$post_date = date('Y-m-d').'<br />';
	$post_timestamp = strtotime(date('Y-m-d'));
	
	
	
	// data select to check exists data
	$sql = "SELECT * FROM tbl_post WHERE post_title=? AND post_description=?";
	$stmt = $con -> prepare($sql);
	$stmt->execute(array($_REQUEST['post_title'],$_REQUEST['ckeditor_post_description']));
	
	// Exists data checking
	$total = $stmt->rowCount();
	if( $total > 0 ){
		throw new PDOException("Title :<strong><i>$_REQUEST[post_title]</i></strong> and <strong><i>Description</i></strong> already exists <br /> ");
	}
	
	
	
	
	
	$m = date('m');
	$y = date('Y');
	// Post insert query
	$sql = "INSERT INTO tbl_post (post_title,post_description,cat_id,tag_id,post_image,post_month,post_year,post_date)VALUES(?,?,?,?,?,?,?,?)";
	$stmt = $con->prepare($sql);
	$stmt->execute(array( $_REQUEST['post_title'],$_REQUEST['ckeditor_post_description'],$_REQUEST['cat_id'],$tag_ids,$f1,$m,$y,$post_date ));
	
		
		
	$success_message = "Data has been inserted successfully";
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
	}
}

?>


<?php include('header.php');?>
	<div class="admin_area">
<?php include('common-admin.php');?>
<form action="" method="post" enctype="multipart/form-data" class="uk-form">
		<table class="last_table">
			<tr>
				<th><h3>Add New Posts</h3><hr/></th>
			</tr>
			<tr>
			<th>
<?php if(isset($error_message)){echo "<span class='error_message'>$error_message</span>";}?>
<?php if(isset($success_message)){echo "<span class='success_message'>$success_message</span>";}?>
			</th>
			</tr>
			<tr>
			    <td>Title:</td>
				<td><input style="width:100%" type="text" name="post_title" value="" /></td><br>
				<td>Description:</td>
				<td><textarea name="ckeditor_post_description" value="" class="c"  id="" cols="31" rows="10"></textarea></td>

				<td>
				Select A Category
				<select name="cat_id" id="">
					<option value="">Select A Category</option>
					
					<?php
					$sql = "SELECT * FROM tbl_category ORDER By cat_name ASC";
					$stmt = $con->prepare($sql);
					$stmt->execute();
					$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
					foreach($result as $row){
						?>
						<option value="<?php echo $row['cat_id'];?>"><?php echo $row['cat_name'];?></option>
						<?php
					}
					
					?>
					
				</select>
				</td>

				<td>
				Select A Tag&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />
				
				<?php
				$stmt = $con->prepare("SELECT * FROM tbl_tag ORDER BY tag_name");
				$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
				foreach($result as $row){
					?>
					<input type="checkbox" name="tag_id[]" value="<?php echo $row['tag_id'];?>" /><span><?php echo $row['tag_name'];?></span><br />
					<?php
				}
				?>
				</td>	
<td>

<a href="">
<?php
// Feature Image show
$sql = "SELECT * FROM tbl_post WHERE post_image ";
$stmt = $con->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach( $result as $row ){

	// determine the first and last iteration in a foreach loop
	
	// FIRST ELEMENT
/* 	if ($row === reset($result)){
        //echo 'FIRST ELEMENT!';
	} */
	
	
	
	// LAST ELEMENT
	if ($row === end($result)){
		?>
		</br />
       <img style="text-align:center;" width="80" height="80" src="../uploads/<?php echo $row['post_image'];?>" alt="" />
	   <?php
	}


}	
echo '<h2>Previous Feature Image Preview </h2>';
?>
</a>
</td>				
<td>Upload Feature Image 
<input class="myButton" type="file" name="feature_image" value="Upload Image" />
</td>				
<hr/>				
<td style="float:left;margin-top:2px">
<input class="myButton" type="submit" name="save_form" value="Save" />
</td>


				
				<td style="float:right;margin-top:15px"><a href="">Edit</a>&nbsp;/&nbsp;<a href="">Delete</a></td>
				
			</tr>
		</table>
</form>
		
	</div>
<?php include('footer.php');?>