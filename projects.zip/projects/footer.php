

<?php include('config.php');?>
<?php
// data preview from tbl_footer
$sql = "SELECT * FROM tbl_footer";
$stmt = $con->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$row['post_description'];
}
?>


	<div id="footer">
	<?php 
	if($row['post_description'] == true){
		echo $row['post_description'];
		
	}
	else{
		?>
		<p>Footer Text goes here...</p>
		<?php
	}
	?>
	
	</div>
	<script src="/dashboard/javascripts/all.js" type="text/javascript"></script>
	<script src="js/jquery-1.8.0.min.js"></script>
	<script src="ckeditor/ckeditor.js"></script>
	<script>CKEDITOR.replace('c_messageP');</script>
	<script src="js/pluigns.js"></script>
	<script src="js/readmore.min.js"></script>
	<script>
		$(document).ready(function(){
			$('.article').readmore({
			  speed: 850,
	collapsedHeight: 445,
       heightMargin: 16,
			  moreLink: '<a style="margin-left:15px;width:15%" href="#">Read More</a>',
			  lessLink: '<a style="margin-left:15px;width:15%" href="#">Read less</a>'
			});
		});
	</script>	
	
	
		<!-- Pagination Ajax Load start -->
		<script type="text/javascript">
			$(document).ready(function(){
			changePagination('0');    
			});
			function changePagination(pageId){
				 $(".flash").show();
				 $(".flash").fadeIn(400).html
							('Loading <img src="ajax-loader.gif" />');
				 var dataString = 'pageId='+ pageId;
				 $.ajax({
					   type: "POST",
					   url: 'pagination-loading.php',
					   data: dataString,
					   cache: false,
					   success: function(result){
					   $(".flash").hide();
							 $("#pageData").html(result);
					   }
				  });
			}
		</script>
		<!-- Pagination Ajax Load end -->
		
		
	<script type="text/javascript">
    // speed in milliseconds
	var scrollSpeed = 70;
	// set the default position
	var current = 0;
	// set the direction
	var direction = 'h';
	function bgscroll(){
    	// 1 pixel row at a time
	    current -= 1;
	    // move the background with backgrond-position css properties
	    $('div.content,div#content').css("backgroundPosition", (direction == 'h') ? current+"px 0" : "0 " + current+"px");
	}
	//Calls the scrolling function repeatedly
	 setInterval("bgscroll()", scrollSpeed);	
	</script>
	
	
	
	<!-- online embed contact us form -->
	<script type="text/javascript">
	(function(d,s,id){var z=d.createElement(s);z.type="text/javascript";z.id=id;z.async=true;z.src="//static.zotabox.com/1/3/13ce1892554af4e131966c95a4e0228f/widgets.js";var sz=d.getElementsByTagName(s)[0];sz.parentNode.insertBefore(z,sz)}(document,"script","zb-embed-code"));
	</script>
	

	<!-- for captcha -->
	<script language='JavaScript' type='text/javascript'>
	function refreshCaptcha()
	{
		var img = document.images['captchaimg'];
		img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
	}
	</script>
	
</body>
</html>
