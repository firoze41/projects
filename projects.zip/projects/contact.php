
<?php include('config.php');?>
<?php include('header.php');?>

<div class="content"> <!-- This div has closed to sidebar.php -->
	




	
	<div class="contact-us">
		<div class="row">
			<div class="col-md-12">
				<div class="contact-form ">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper <a href="">suscipit lobortis</a> nisl ut aliquip ex ea commodo consequat.</p>
					<form method="post" action="">
						<label for="name" class="nameLabel">Name</label>
						  <input id="name" type="text" name="name" placeholder="Enter your name...">
						<label for="email" class="emailLabel">Email</label>
						  <input id="email" type="text" name="email" placeholder="Enter your email...">
						<label for="subject">Subject</label>
						  <input id="subject" type="text" name="subject" placeholder="Your subject...">
						<label for="message" class="messageLabel">Message</label>
						  <textarea id="message" name="message" placeholder="Your message..."></textarea>
						<button type="submit">Send</button>
					</form>
				</div>
			</div>
		</div>
	</div>		
</div> 
<?php include_once('footer.php');?>
